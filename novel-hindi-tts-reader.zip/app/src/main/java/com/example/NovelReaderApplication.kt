package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.NovelRepository
import com.example.data.repository.SettingsRepository
import com.example.parser.ParserManager
import com.example.translation.CompositeTranslationManager
import com.example.tts.TtsPlaybackManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NovelReaderApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var novelRepository: NovelRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var parserManager: ParserManager
        private set

    lateinit var translationManager: CompositeTranslationManager
        private set

    lateinit var ttsPlaybackManager: TtsPlaybackManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        novelRepository = NovelRepository(database)
        settingsRepository = SettingsRepository(database)
        parserManager = ParserManager()
        translationManager = CompositeTranslationManager()
        ttsPlaybackManager = TtsPlaybackManager.getInstance(this)

        CoroutineScope(Dispatchers.IO).launch {
            novelRepository.checkAndSeedDemoNovel()
            settingsRepository.getSettings() // ensure defaults created
        }
    }

    companion object {
        lateinit var instance: NovelReaderApplication
            private set
    }
}
