package com.example.data.demo

import com.example.data.local.entity.ChapterEntity
import com.example.data.local.entity.NovelEntity
import com.example.data.local.entity.TranslationEntity

object DemoNovelProvider {
    const val DEMO_NOVEL_TITLE = "The Mystic Himalayan Scroll"
    const val DEMO_AUTHOR = "Aarav Sharma"
    const val DEMO_SOURCE_URL = "https://novelhinditts.example.com/mystic-scroll"

    fun getDemoNovel(): NovelEntity {
        return NovelEntity(
            id = 1,
            title = DEMO_NOVEL_TITLE,
            author = DEMO_AUTHOR,
            sourceUrl = DEMO_SOURCE_URL,
            coverImageUrl = null,
            currentChapter = 1,
            importedChaptersCount = 3,
            readingProgress = 0f,
            lastOpenedTime = System.currentTimeMillis(),
            isFavorite = true,
            description = "An original fantasy epic set in the mystical high altitude peaks of Uttarakhand, where ancient sages guard forgotten celestial techniques."
        )
    }

    fun getDemoChapters(novelId: Long = 1): List<ChapterEntity> {
        return listOf(
            ChapterEntity(
                id = 1,
                novelId = novelId,
                chapterNumber = 1,
                title = "Chapter 1: The Whispers in the Mist",
                content = """
                    Dawn broke across the serrated peaks of the Himalayas, painting the snowfields in hues of cold amber and brushed silver.

                    Vikram tightened the strap of his worn leather rucksack and took a measured breath of the razor-sharp mountain air. At eighteen thousand feet, every lungful felt like crushed glass, yet his spirit remained unbroken.

                    "If the ancient records are correct," Vikram whispered to himself, adjusting his snow goggles, "the Agastya Sanctuary should lie just beyond the frozen gorge."

                    Behind him, the endless expanse of clouds rolled like a restless sea, cutting off all ties to the mortal cities below. He was no longer a common wanderer; he had embarked on the arduous path of inner spiritual cultivation.

                    Suddenly, a low vibration rippled through the crystalline ice beneath his boots. The wind paused, as if the mountain itself held its breath.

                    "Who seeks the forgotten wisdom of the snowy peaks?" a profound voice echoed through the freezing mist, carrying the weight of centuries.

                    Vikram steadied his stance, his fingers grasping the brass talisman hanging around his neck. "I am Vikram of the Northern Valley. I have walked three thousand leagues to seek the celestial truth."

                    A faint golden radiance shimmered through the fog, revealing stone steps carved directly into the sheer vertical cliff ahead. The adventure of a lifetime had finally begun.
                """.trimIndent(),
                sourceUrl = "https://novelhinditts.example.com/mystic-scroll/chapter-1",
                nextChapterUrl = "https://novelhinditts.example.com/mystic-scroll/chapter-2",
                prevChapterUrl = null,
                isTranslated = false,
                readingProgress = 0f,
                isTtsPlayed = false
            ),
            ChapterEntity(
                id = 2,
                novelId = novelId,
                chapterNumber = 2,
                title = "Chapter 2: The Ancient Monastery of Agastya",
                content = """
                    Each carved step was lined with glowing azure runes that pulsed in rhythm with Vikram's accelerating heartbeat.

                    As he climbed past the cloudline, the biting gale subsided into an eerie, sacred silence. Ahead stood colossal wooden gates constructed of thousand-year-old deodar cedar, untouched by decay or frost.

                    "The Sanctuary of Agastya..." Vikram murmured with profound reverence.

                    Without touching the surface, the heavy gates groaned and swung inward smoothly. Inside was not cold stone, but a sunlit courtyard blooming with golden lotus flowers in crystal pools of heated spring water.

                    An elder clothed in simple saffron robes sat cross-legged upon a raised stone dais under a blossoming magnolia tree. His silver hair fell like water, and his eyes held the brilliance of morning stars.

                    "Welcome, young disciple," the Elder spoke, his voice melodious yet commanding. "You have crossed the Valley of Despair without wavering. But having strength of foot does not guarantee strength of mind."

                    "Master, I seek to cultivate the spiritual energy necessary to protect the mortal realm from the descending shadow," Vikram said, bowing deeply with joined palms.

                    The Elder smiled gently. "Then sit before the pool. Let the waters mirror not your face, but your deepest truth."
                """.trimIndent(),
                sourceUrl = "https://novelhinditts.example.com/mystic-scroll/chapter-2",
                nextChapterUrl = "https://novelhinditts.example.com/mystic-scroll/chapter-3",
                prevChapterUrl = "https://novelhinditts.example.com/mystic-scroll/chapter-1",
                isTranslated = false,
                readingProgress = 0f,
                isTtsPlayed = false
            ),
            ChapterEntity(
                id = 3,
                novelId = novelId,
                chapterNumber = 3,
                title = "Chapter 3: Awakening of the Celestial Core",
                content = """
                    Vikram took his seat upon the smooth river stone at the edge of the lotus pond. The thermal mist swirled around his crossed legs, soothing his mountain-chapped skin.

                    "Close your eyes," the Elder instructed softly. "Do not search for power in the sky. Look beneath your ribs, where the divine flame resides in silence."

                    Taking a deep breath, Vikram sank his consciousness inward. In the beginning, there was only darkness and the rhythmic thudding of his heart. But slowly, a microscopic speck of emerald light emerged at the center of his chest.

                    It spun gently, drawing in the pure mountain prana around him. The cold fatigue of the past three months dissolved, replaced by a surge of warmth flowing through his meridians like liquid sunshine.

                    "He has formed the spiritual core on his first attempt," the Elder observed with quiet amazement. "The legends spoke of a child born during the winter solstice, but few believed."

                    As Vikram opened his eyes, a faint emerald gleam flashed within his pupils. The world seemed vastly different—sharper, richer, and full of vibrant life.

                    "You have taken your first step upon the immortal path," the Elder announced, holding out a jade token carved with the insignia of a flying crane. "Tomorrow, your true trial begins."
                """.trimIndent(),
                sourceUrl = "https://novelhinditts.example.com/mystic-scroll/chapter-3",
                nextChapterUrl = null,
                prevChapterUrl = "https://novelhinditts.example.com/mystic-scroll/chapter-2",
                isTranslated = false,
                readingProgress = 0f,
                isTtsPlayed = false
            )
        )
    }

    fun getDemoTranslations(novelId: Long = 1): List<TranslationEntity> {
        return listOf(
            TranslationEntity(
                chapterId = 1,
                sourceLanguage = "en",
                targetLanguage = "hi",
                style = "NATURAL",
                translatedTitle = "अध्याय 1: कुहासे में फुसफुसाहट",
                translatedContent = """
                    हिमालय की नुकीली बर्फीली चोटियों पर भोर की पहली किरण फूटी, जिसने बर्फ के मैदानों को ठंडे अंबर और चमकीली चांदी के रंगों में रंग दिया।

                    विक्रम ने अपने पुराने चमड़े के बैग का पट्टा कसा और पहाड़ की बर्फीली, तीखी हवा में एक गहरी सांस ली। अठारह हजार फीट की ऊंचाई पर, हर सांस कांच के टुकड़ों जैसी चुभ रही थी, फिर भी उसका हौसला अटूट था।

                    "यदि प्राचीन अभिलेख सही हैं," विक्रम ने अपने बर्फ के चश्मे को ठीक करते हुए खुद से फुसफुसाया, "तो अगस्त्य आश्रम इस जमी हुई खाई के ठीक पार होना चाहिए।"

                    उसके पीछे, बादलों का अंतहीन विस्तार एक अशांत समुद्र की तरह उमड़ रहा था, जिसने नीचे के नश्वर शहरों से सारे संबंध काट दिए थे। अब वह कोई साधारण भटका हुआ मुसाफिर नहीं था; उसने आंतरिक आध्यात्मिक साधना के कठिन मार्ग पर कदम रख दिया था।

                    अचानक, उसके जूतों के नीचे जमी पारदर्शी बर्फ में एक हल्की कंपन महसूस हुई। हवा थम गई, मानो पहाड़ ने खुद अपनी सांसें रोक ली हों।

                    "बर्फीली चोटियों के भूले-बिसरे ज्ञान की खोज में कौन आया है?" सदियों का भार समेटे एक गंभीर और रहस्यमयी आवाज़ कड़ाके की धुंध में गूंजी।

                    विक्रम ने अपने कदम जमाए, उसकी उंगलियों ने गले में लटके पीतल के ताबीज को मजबूती से पकड़ लिया। "मैं उत्तरी घाटी का विक्रम हूं। दिव्य सत्य की खोज में मैं तीन हजार कोस चलकर आया हूं।"

                    कोहरे के बीच से एक मंद स्वर्णिम आभा चमकी, जिसने सामने खड़ी सीधी चट्टान पर तराशी गई पत्थर की सीढ़ियों को उजागर कर दिया। उसके जीवन का सबसे बड़ा रोमांच आखिरकार शुरू हो चुका था।
                """.trimIndent()
            ),
            TranslationEntity(
                chapterId = 2,
                sourceLanguage = "en",
                targetLanguage = "hi",
                style = "NATURAL",
                translatedTitle = "अध्याय 2: अगस्त्य का प्राचीन मठ",
                translatedContent = """
                    प्रत्येक तराशी गई सीढ़ी पर चमकते हुए नीले रंग के दिव्य प्रतीक उकेरे हुए थे, जो विक्रम की तेज होती धड़कनों की लय में स्पंदित हो रहे थे।

                    जैसे ही वह बादलों की रेखा को पार कर ऊपर चढ़ा, चुभने वाली बर्फीली हवा एक रहस्यमयी, पावन शांति में बदल गई। आगे हजार साल पुरानी देवदार की लकड़ी से बने विशालकाय फाटक खड़े थे, जिन पर समय या पाले का कोई असर नहीं हुआ था।

                    "अगस्त्य का पावन धाम..." विक्रम ने अगाध श्रद्धा के साथ धीमे स्वर में कहा।

                    बिना किसी स्पर्श के, वे भारी कपाट हल्की चरमराहट के साथ धीरे से अंदर की ओर खुल गए। अंदर ठंडे पत्थर नहीं थे, बल्कि धूप से जगमगाता हुआ एक आंगन था, जहाँ गर्म पानी के जलकुंडों में सुनहरे कमल के फूल खिले हुए थे।

                    सादे भगवा वस्त्र पहने एक वृद्ध महर्षि खिले हुए चंपा के पेड़ के नीचे एक ऊंचे पत्थर के चबूतरे पर पद्मासन में बैठे थे। उनके चांदी जैसे सफेद बाल पानी की तरह लहरा रहे थे, और उनकी आंखों में भोर के तारों जैसी दिव्य चमक थी।

                    "स्वागत है, युवा शिष्य," महर्षि बोले, उनकी आवाज मधुर होते हुए भी प्रभावशाली थी। "तुम बिना डगमगाए निराशा की घाटी पार कर आए हो। लेकिन कदमों की शक्ति मन की दृढ़ता की गारंटी नहीं देती।"

                    "गुरुदेव, मैं आने वाली अंधकारमय छाया से नश्वर संसार की रक्षा के लिए आवश्यक आध्यात्मिक ऊर्जा की साधना करना चाहता हूं," विक्रम ने हाथ जोड़कर श्रद्धापूर्वक झुकते हुए कहा।

                    महर्षि मंद मुस्कुराए। "तो फिर इस सरोवर के सामने बैठो। इन जलों को तुम्हारे चेहरे का नहीं, बल्कि तुम्हारे अंतर के परम सत्य का प्रतिबिंब दिखाने दो।"
                """.trimIndent()
            ),
            TranslationEntity(
                chapterId = 3,
                sourceLanguage = "en",
                targetLanguage = "hi",
                style = "NATURAL",
                translatedTitle = "अध्याय 3: दिव्य कोर का जागरण",
                translatedContent = """
                    विक्रम कमल सरोवर के किनारे एक चिकने नदी के पत्थर पर बैठ गया। गर्म पानी की भाप उसके पैरों के चारों ओर घूमने लगी, जिससे पहाड़ की ठंड से फटी उसकी त्वचा को राहत मिली।

                    "अपनी आँखें बंद करो," महर्षि ने धीरे से निर्देश दिया। "आकाश में शक्ति मत खोजो। अपनी पसलियों के नीचे देखो, जहाँ दिव्य अग्नि मौन में निवास करती है।"

                    गहरी सांस लेते हुए, विक्रम ने अपनी चेतना को भीतर की ओर केंद्रित किया। शुरुआत में केवल अंधकार और उसके दिल की धड़कनें थीं। लेकिन धीरे-धीरे, उसकी छाती के केंद्र में पन्ना जैसी हरी रोशनी का एक सूक्ष्म बिंदु प्रकट हुआ।

                    यह बिंदु धीरे-धीरे घूमने लगा, और अपने चारों ओर की शुद्ध पर्वतीय प्राण ऊर्जा को आकर्षित करने लगा। पिछले तीन महीनों की बर्फीली थकान गायब हो गई, और उसकी जगह एक सुखद गर्माहट ने ले ली, जो तरल धूप की तरह उसकी नाड़ियों में बहने लगी।

                    "उसने अपने पहले ही प्रयास में आध्यात्मिक कोर का निर्माण कर लिया," महर्षि ने शांत विस्मय के साथ देखा। "पौराणिक कथाओं में शीत संक्रांति के दौरान जन्मे एक बालक की बात कही गई थी, लेकिन बहुत कम लोगों को विश्वास था।"

                    जैसे ही विक्रम ने अपनी आँखें खोलीं, उसकी पुतलियों में पन्ना जैसी हरी चमक कौंध गई। संसार बिल्कुल अलग दिखने लगा—अधिक स्पष्ट, समृद्ध और जीवंत ऊर्जा से भरपूर।

                    "तुमने अमरत्व के मार्ग पर अपना पहला कदम रख दिया है," महर्षि ने उड़ते हुए सारस के प्रतीक वाले जेड के पदक को आगे बढ़ाते हुए घोषणा की। "कल तुम्हारी वास्तविक परीक्षा आरंभ होगी।"
                """.trimIndent()
            )
        )
    }
}
