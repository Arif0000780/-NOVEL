package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.ChapterEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE novelId = :novelId ORDER BY chapterNumber ASC")
    fun getChaptersForNovel(novelId: Long): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE novelId = :novelId ORDER BY chapterNumber ASC")
    suspend fun getChaptersListForNovel(novelId: Long): List<ChapterEntity>

    @Query("SELECT * FROM chapters WHERE id = :id")
    suspend fun getChapterById(id: Long): ChapterEntity?

    @Query("SELECT * FROM chapters WHERE id = :id")
    fun getChapterFlow(id: Long): Flow<ChapterEntity?>

    @Query("SELECT * FROM chapters WHERE novelId = :novelId AND chapterNumber = :number LIMIT 1")
    suspend fun getChapterByNumber(novelId: Long, number: Int): ChapterEntity?

    @Query("SELECT * FROM chapters WHERE novelId = :novelId AND (title LIKE '%' || :query || '%' OR chapterNumber LIKE '%' || :query || '%') ORDER BY chapterNumber ASC")
    fun searchChapters(novelId: Long, query: String): Flow<List<ChapterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>): List<Long>

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Query("UPDATE chapters SET readingProgress = :progress WHERE id = :id")
    suspend fun updateReadingProgress(id: Long, progress: Float)

    @Query("UPDATE chapters SET isTranslated = :isTranslated WHERE id = :id")
    suspend fun updateTranslationStatus(id: Long, isTranslated: Boolean)

    @Query("UPDATE chapters SET isTtsPlayed = :played WHERE id = :id")
    suspend fun updateTtsPlayedStatus(id: Long, played: Boolean)

    @Query("DELETE FROM chapters WHERE id = :id")
    suspend fun deleteChapter(id: Long)

    @Query("DELETE FROM chapters WHERE novelId = :novelId")
    suspend fun deleteChaptersForNovel(novelId: Long)
}
