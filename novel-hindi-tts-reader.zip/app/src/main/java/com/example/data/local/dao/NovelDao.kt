package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.NovelEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NovelDao {
    @Query("SELECT * FROM novels ORDER BY lastOpenedTime DESC")
    fun getAllNovels(): Flow<List<NovelEntity>>

    @Query("SELECT * FROM novels WHERE isFavorite = 1 ORDER BY lastOpenedTime DESC")
    fun getFavoriteNovels(): Flow<List<NovelEntity>>

    @Query("SELECT * FROM novels ORDER BY lastOpenedTime DESC LIMIT :limit")
    fun getRecentNovels(limit: Int = 10): Flow<List<NovelEntity>>

    @Query("SELECT * FROM novels WHERE id = :id")
    suspend fun getNovelById(id: Long): NovelEntity?

    @Query("SELECT * FROM novels WHERE id = :id")
    fun getNovelFlow(id: Long): Flow<NovelEntity?>

    @Query("SELECT * FROM novels WHERE sourceUrl = :sourceUrl LIMIT 1")
    suspend fun getNovelByUrl(sourceUrl: String): NovelEntity?

    @Query("SELECT * FROM novels WHERE title LIKE '%' || :query || '%' OR author LIKE '%' || :query || '%'")
    fun searchNovels(query: String): Flow<List<NovelEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNovel(novel: NovelEntity): Long

    @Update
    suspend fun updateNovel(novel: NovelEntity)

    @Query("UPDATE novels SET isFavorite = :isFav WHERE id = :id")
    suspend fun setFavorite(id: Long, isFav: Boolean)

    @Query("UPDATE novels SET currentChapter = :chapterNum, readingProgress = :progress, lastOpenedTime = :time WHERE id = :id")
    suspend fun updateReadingState(id: Long, chapterNum: Int, progress: Float, time: Long = System.currentTimeMillis())

    @Query("UPDATE novels SET title = :newTitle WHERE id = :id")
    suspend fun renameNovel(id: Long, newTitle: String)

    @Query("DELETE FROM novels WHERE id = :id")
    suspend fun deleteNovel(id: Long)
}
