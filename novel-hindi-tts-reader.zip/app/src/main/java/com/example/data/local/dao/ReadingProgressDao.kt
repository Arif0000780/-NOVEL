package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.ReadingProgressEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReadingProgressDao {
    @Query("SELECT * FROM reading_progress WHERE chapterId = :chapterId LIMIT 1")
    suspend fun getProgressForChapter(chapterId: Long): ReadingProgressEntity?

    @Query("SELECT * FROM reading_progress WHERE chapterId = :chapterId LIMIT 1")
    fun getProgressFlowForChapter(chapterId: Long): Flow<ReadingProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: ReadingProgressEntity): Long

    @Query("DELETE FROM reading_progress WHERE chapterId = :chapterId")
    suspend fun deleteProgressForChapter(chapterId: Long)

    @Query("DELETE FROM reading_progress")
    suspend fun clearAllReadingProgress()
}
