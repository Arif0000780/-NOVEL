package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.TranslationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TranslationDao {
    @Query("SELECT * FROM translations WHERE chapterId = :chapterId LIMIT 1")
    suspend fun getTranslationForChapter(chapterId: Long): TranslationEntity?

    @Query("SELECT * FROM translations WHERE chapterId = :chapterId LIMIT 1")
    fun getTranslationFlowForChapter(chapterId: Long): Flow<TranslationEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTranslation(translation: TranslationEntity): Long

    @Query("DELETE FROM translations WHERE chapterId = :chapterId")
    suspend fun deleteTranslationForChapter(chapterId: Long)

    @Query("DELETE FROM translations")
    suspend fun clearAllTranslations()
}
