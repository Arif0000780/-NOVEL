package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.TtsProgressEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TtsProgressDao {
    @Query("SELECT * FROM tts_progress WHERE chapterId = :chapterId LIMIT 1")
    suspend fun getTtsProgressForChapter(chapterId: Long): TtsProgressEntity?

    @Query("SELECT * FROM tts_progress WHERE chapterId = :chapterId LIMIT 1")
    fun getTtsProgressFlow(chapterId: Long): Flow<TtsProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTtsProgress(progress: TtsProgressEntity): Long

    @Query("DELETE FROM tts_progress WHERE chapterId = :chapterId")
    suspend fun deleteTtsProgressForChapter(chapterId: Long)

    @Query("DELETE FROM tts_progress")
    suspend fun clearAllTtsProgress()
}
