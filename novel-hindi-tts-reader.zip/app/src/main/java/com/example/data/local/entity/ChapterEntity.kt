package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "chapters",
    foreignKeys = [
        ForeignKey(
            entity = NovelEntity::class,
            parentColumns = ["id"],
            childColumns = ["novelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["novelId"]), Index(value = ["novelId", "chapterNumber"], unique = true)]
)
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val novelId: Long,
    val chapterNumber: Int,
    val title: String,
    val content: String,
    val sourceUrl: String,
    val nextChapterUrl: String? = null,
    val prevChapterUrl: String? = null,
    val isTranslated: Boolean = false,
    val readingProgress: Float = 0f,
    val isTtsPlayed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
