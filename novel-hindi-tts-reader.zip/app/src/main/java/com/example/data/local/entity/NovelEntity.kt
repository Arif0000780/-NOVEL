package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "novels")
data class NovelEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val coverImageUrl: String? = null,
    val author: String? = null,
    val sourceUrl: String,
    val currentChapter: Int = 1,
    val importedChaptersCount: Int = 1,
    val readingProgress: Float = 0f,
    val lastOpenedTime: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val description: String? = null
)
