package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class SettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val fontSize: Int = 18,
    val lineSpacing: Float = 1.6f,
    val paragraphSpacing: Int = 16,
    val fontFamily: String = "DEFAULT",
    val readerTheme: String = "LIGHT", // "LIGHT", "DARK", "SEPIA"
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "hi",
    val translationStyle: String = "NATURAL", // "NATURAL", "SIMPLE", "LITERARY"
    val translationProvider: String = "SMART_LOCAL", // "SMART_LOCAL", "GEMINI_AI"
    val autoTranslate: Boolean = true,
    val ttsVoice: String = "default",
    val speechSpeed: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val autoPlay: Boolean = false,
    val autoNextParagraph: Boolean = true,
    val autoNextChapter: Boolean = true,
    val wifiOnly: Boolean = false,
    val retryFailedRequests: Boolean = true
)
