package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "tts_progress",
    foreignKeys = [
        ForeignKey(
            entity = ChapterEntity::class,
            parentColumns = ["id"],
            childColumns = ["chapterId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["chapterId"], unique = true)]
)
data class TtsProgressEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val chapterId: Long,
    val paragraphIndex: Int = 0,
    val charOffset: Int = 0,
    val speed: Float = 1.0f,
    val pitch: Float = 1.0f,
    val isCompleted: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
