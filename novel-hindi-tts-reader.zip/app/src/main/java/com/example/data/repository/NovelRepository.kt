package com.example.data.repository

import com.example.data.demo.DemoNovelProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.*
import com.example.parser.ExtractedChapter
import com.example.translation.isPureHindi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class NovelRepository(private val database: AppDatabase) {

    private val novelDao = database.novelDao()
    private val chapterDao = database.chapterDao()
    private val bookmarkDao = database.bookmarkDao()
    private val readingProgressDao = database.readingProgressDao()
    private val translationDao = database.translationDao()
    private val ttsProgressDao = database.ttsProgressDao()

    suspend fun checkAndSeedDemoNovel() = withContext(Dispatchers.IO) {
        val existing = novelDao.getNovelById(1)
        if (existing == null) {
            val demoNovel = DemoNovelProvider.getDemoNovel()
            val novelId = novelDao.insertNovel(demoNovel)
            val demoChapters = DemoNovelProvider.getDemoChapters(novelId)
            chapterDao.insertChapters(demoChapters)
        }

        // Always ensure pure, complete Hindi translations are seeded for demo chapters
        // and replace any outdated mixed English-Hindi text in database
        val demoTranslations = DemoNovelProvider.getDemoTranslations(1)
        for (translation in demoTranslations) {
            val existingTrans = translationDao.getTranslationForChapter(translation.chapterId)
            if (existingTrans == null || !isPureHindi(existingTrans.translatedContent)) {
                translationDao.saveTranslation(translation)
                chapterDao.updateTranslationStatus(translation.chapterId, true)
            }
        }
    }

    fun getAllNovels(): Flow<List<NovelEntity>> = novelDao.getAllNovels()
    fun getFavoriteNovels(): Flow<List<NovelEntity>> = novelDao.getFavoriteNovels()
    fun getRecentNovels(limit: Int = 10): Flow<List<NovelEntity>> = novelDao.getRecentNovels(limit)
    fun searchNovels(query: String): Flow<List<NovelEntity>> = novelDao.searchNovels(query)

    suspend fun getNovelById(id: Long): NovelEntity? = novelDao.getNovelById(id)
    fun getNovelFlow(id: Long): Flow<NovelEntity?> = novelDao.getNovelFlow(id)

    fun getChaptersForNovel(novelId: Long): Flow<List<ChapterEntity>> = chapterDao.getChaptersForNovel(novelId)
    suspend fun getChaptersListForNovel(novelId: Long): List<ChapterEntity> = chapterDao.getChaptersListForNovel(novelId)
    suspend fun getChapterById(id: Long): ChapterEntity? = chapterDao.getChapterById(id)
    fun getChapterFlow(id: Long): Flow<ChapterEntity?> = chapterDao.getChapterFlow(id)

    suspend fun toggleFavorite(id: Long, isFav: Boolean) = novelDao.setFavorite(id, isFav)
    suspend fun renameNovel(id: Long, newTitle: String) = novelDao.renameNovel(id, newTitle)
    suspend fun deleteNovel(id: Long) = novelDao.deleteNovel(id)

    suspend fun updateReadingProgress(novelId: Long, chapterId: Long, chapterNumber: Int, progress: Float, paragraphIndex: Int) = withContext(Dispatchers.IO) {
        chapterDao.updateReadingProgress(chapterId, progress)
        novelDao.updateReadingState(novelId, chapterNumber, progress)
        readingProgressDao.saveProgress(
            ReadingProgressEntity(
                novelId = novelId,
                chapterId = chapterId,
                progressPercent = progress,
                paragraphIndex = paragraphIndex,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun getReadingProgress(chapterId: Long): ReadingProgressEntity? = readingProgressDao.getProgressForChapter(chapterId)

    suspend fun saveBookmark(novelId: Long, chapterId: Long, chapterTitle: String, paragraphIndex: Int, note: String = "") {
        bookmarkDao.insertBookmark(
            BookmarkEntity(
                novelId = novelId,
                chapterId = chapterId,
                chapterTitle = chapterTitle,
                paragraphIndex = paragraphIndex,
                note = note
            )
        )
    }

    fun getBookmarksForNovel(novelId: Long): Flow<List<BookmarkEntity>> = bookmarkDao.getBookmarksForNovel(novelId)
    suspend fun deleteBookmark(id: Long) = bookmarkDao.deleteBookmark(id)

    // Translation
    suspend fun getTranslationForChapter(chapterId: Long): TranslationEntity? = translationDao.getTranslationForChapter(chapterId)
    fun getTranslationFlowForChapter(chapterId: Long): Flow<TranslationEntity?> = translationDao.getTranslationFlowForChapter(chapterId)

    suspend fun saveTranslation(translation: TranslationEntity) = withContext(Dispatchers.IO) {
        translationDao.saveTranslation(translation)
        chapterDao.updateTranslationStatus(translation.chapterId, true)
    }

    // TTS progress
    suspend fun getTtsProgress(chapterId: Long): TtsProgressEntity? = ttsProgressDao.getTtsProgressForChapter(chapterId)
    fun getTtsProgressFlow(chapterId: Long): Flow<TtsProgressEntity?> = ttsProgressDao.getTtsProgressFlow(chapterId)

    suspend fun saveTtsProgress(progress: TtsProgressEntity) = withContext(Dispatchers.IO) {
        ttsProgressDao.saveTtsProgress(progress)
        chapterDao.updateTtsPlayedStatus(progress.chapterId, true)
    }

    // URL Import flow
    suspend fun importExtractedChapter(extracted: ExtractedChapter): Long = withContext(Dispatchers.IO) {
        // Find existing novel by source URL or title
        var novel = novelDao.getNovelByUrl(extracted.sourceUrl)
        if (novel == null) {
            val all = novelDao.getNovelById(1)
            novel = NovelEntity(
                title = extracted.novelTitle,
                author = extracted.author,
                sourceUrl = extracted.sourceUrl,
                coverImageUrl = extracted.coverImageUrl,
                currentChapter = extracted.chapterNumber,
                importedChaptersCount = 1,
                lastOpenedTime = System.currentTimeMillis()
            )
            val newNovelId = novelDao.insertNovel(novel)
            novel = novel.copy(id = newNovelId)
        } else {
            novel = novel.copy(
                importedChaptersCount = novel.importedChaptersCount + 1,
                lastOpenedTime = System.currentTimeMillis()
            )
            novelDao.updateNovel(novel)
        }

        // Check if chapter already exists for this novel & chapterNumber
        val existingChapter = chapterDao.getChapterByNumber(novel.id, extracted.chapterNumber)
        val chapterToSave = if (existingChapter != null) {
            existingChapter.copy(
                title = extracted.chapterTitle,
                content = extracted.content,
                nextChapterUrl = extracted.nextChapterUrl ?: existingChapter.nextChapterUrl,
                prevChapterUrl = extracted.prevChapterUrl ?: existingChapter.prevChapterUrl
            )
        } else {
            ChapterEntity(
                novelId = novel.id,
                chapterNumber = extracted.chapterNumber,
                title = extracted.chapterTitle,
                content = extracted.content,
                sourceUrl = extracted.sourceUrl,
                nextChapterUrl = extracted.nextChapterUrl,
                prevChapterUrl = extracted.prevChapterUrl
            )
        }

        chapterDao.insertChapter(chapterToSave)
    }

    suspend fun clearTranslationCache() = withContext(Dispatchers.IO) {
        translationDao.clearAllTranslations()
    }

    suspend fun clearReadingData() = withContext(Dispatchers.IO) {
        readingProgressDao.clearAllReadingProgress()
        ttsProgressDao.clearAllTtsProgress()
    }
}
