package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.SettingsEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class SettingsRepository(private val database: AppDatabase) {

    private val settingsDao = database.settingsDao()

    fun getSettingsFlow(): Flow<SettingsEntity?> = settingsDao.getSettingsFlow()

    suspend fun getSettings(): SettingsEntity = withContext(Dispatchers.IO) {
        settingsDao.getSettings() ?: SettingsEntity().also {
            settingsDao.saveSettings(it)
        }
    }

    suspend fun updateSettings(settings: SettingsEntity) = withContext(Dispatchers.IO) {
        settingsDao.saveSettings(settings)
    }

    suspend fun updateSpeed(speed: Float) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(speechSpeed = speed))
    }

    suspend fun updatePitch(pitch: Float) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(speechPitch = pitch))
    }

    suspend fun updateVoice(voiceName: String) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(ttsVoice = voiceName))
    }

    suspend fun updateReaderTheme(theme: String) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(readerTheme = theme))
    }

    suspend fun updateFontSize(size: Int) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(fontSize = size.coerceIn(12, 36)))
    }

    suspend fun updateLineSpacing(spacing: Float) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(lineSpacing = spacing.coerceIn(1.2f, 2.4f)))
    }

    suspend fun updateParagraphSpacing(spacing: Int) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(paragraphSpacing = spacing.coerceIn(8, 36)))
    }

    suspend fun updateTranslationStyle(style: String) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(translationStyle = style))
    }

    suspend fun updateTranslationProvider(provider: String) = withContext(Dispatchers.IO) {
        val current = getSettings()
        settingsDao.saveSettings(current.copy(translationProvider = provider))
    }
}
