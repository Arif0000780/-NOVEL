package com.example.parser

data class ExtractedChapter(
    val novelTitle: String,
    val chapterTitle: String,
    val chapterNumber: Int,
    val content: String,
    val nextChapterUrl: String? = null,
    val prevChapterUrl: String? = null,
    val author: String? = null,
    val sourceUrl: String,
    val coverImageUrl: String? = null
)
