package com.example.parser

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.safety.Safelist
import java.net.URI
import java.util.regex.Pattern

class GenericWebParser : WebsiteParser {
    override val name: String = "Generic Web Novel Parser"

    override fun canParse(url: String): Boolean = true // Fallback for any standard webpage

    override fun parse(html: String, url: String): ExtractedChapter {
        val doc: Document = Jsoup.parse(html, url)

        // Remove non-content elements
        doc.select("script, style, nav, header, footer, noscript, iframe, svg, form, aside, .ad, .ads, .advertisement, .comments, #comments, .sidebar, #sidebar, .share, .social, .breadcrumb").remove()

        // 1. Extract Novel Title
        var novelTitle = doc.select("meta[property=og:site_name]").attr("content").trim()
        if (novelTitle.isEmpty()) {
            val siteNameMeta = doc.select("meta[name=application-name]").attr("content").trim()
            novelTitle = siteNameMeta
        }
        if (novelTitle.isEmpty()) {
            val fullTitle = doc.title().trim()
            if (fullTitle.contains(" - ")) {
                val parts = fullTitle.split(" - ")
                novelTitle = parts.last().trim()
            } else if (fullTitle.contains(" | ")) {
                val parts = fullTitle.split(" | ")
                novelTitle = parts.last().trim()
            } else {
                novelTitle = fullTitle
            }
        }
        if (novelTitle.isEmpty()) {
            novelTitle = try {
                URI(url).host?.replace("www.", "")?.substringBefore(".")?.replaceFirstChar { it.uppercase() } ?: "Web Novel"
            } catch (e: Exception) {
                "Web Novel"
            }
        }

        // 2. Extract Chapter Title
        var chapterTitle = ""
        val chapterTitleCandidates = doc.select("h1, h2.chapter-title, .chapter-title, #chapter-title, .entry-title, .post-title, .reader-chapter-title")
        for (el in chapterTitleCandidates) {
            val text = el.text().trim()
            if (text.isNotEmpty() && text.length < 150) {
                chapterTitle = text
                break
            }
        }
        if (chapterTitle.isEmpty()) {
            val titleText = doc.title().trim()
            chapterTitle = if (titleText.contains(" - ")) {
                titleText.split(" - ").first().trim()
            } else if (titleText.contains(" | ")) {
                titleText.split(" | ").first().trim()
            } else {
                titleText.ifEmpty { "Chapter 1" }
            }
        }

        // 3. Extract Chapter Number
        var chapterNumber = 1
        val chapterPattern = Pattern.compile("(?i)(?:chapter|ch|ep|episode)[._\\s-]*(\\d+)")
        val matcherTitle = chapterPattern.matcher(chapterTitle)
        if (matcherTitle.find()) {
            chapterNumber = matcherTitle.group(1)?.toIntOrNull() ?: 1
        } else {
            val matcherUrl = chapterPattern.matcher(url)
            if (matcherUrl.find()) {
                chapterNumber = matcherUrl.group(1)?.toIntOrNull() ?: 1
            }
        }

        // 4. Extract Main Chapter Text
        var content = ""
        // Priority selector candidates
        val contentSelectors = listOf(
            "#chapter-content",
            ".chapter-content",
            "#chapter-text",
            ".chapter-text",
            ".reading-content",
            ".entry-content",
            ".post-content",
            ".text-content",
            "#article-content",
            ".article-content",
            "article",
            "[itemprop=articleBody]",
            ".ep-content",
            "#readcontent",
            ".read-content",
            "main",
            "#content"
        )

        var bestContentElement: Element? = null
        for (selector in contentSelectors) {
            val el = doc.selectFirst(selector)
            if (el != null && el.text().length > 200) {
                bestContentElement = el
                break
            }
        }

        // If not found, look for container with highest paragraph count or highest text length
        if (bestContentElement == null) {
            val containers = doc.select("div, section")
            var maxPCount = 0
            for (container in containers) {
                val pCount = container.select("p").size
                if (pCount > maxPCount && container.text().length > 300) {
                    maxPCount = pCount
                    bestContentElement = container
                }
            }
        }

        if (bestContentElement != null) {
            // Clean inner unwanted elements inside content element
            bestContentElement.select("script, style, button, .ad, .ads, .advertisement, [id*=ad], [class*=ad]").remove()
            val paragraphs = bestContentElement.select("p")
            content = if (paragraphs.isNotEmpty()) {
                paragraphs.map { it.text().trim() }
                    .filter { it.isNotEmpty() && !isAdOrNavigationParagraph(it) }
                    .joinToString("\n\n")
            } else {
                // Handle text with <br> tags
                bestContentElement.select("br").append("\\n")
                bestContentElement.text()
                    .replace("\\n", "\n")
                    .lines()
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && !isAdOrNavigationParagraph(it) }
                    .joinToString("\n\n")
            }
        }

        if (content.isEmpty()) {
            content = doc.body()?.text()?.take(5000) ?: "No readable chapter text found on page."
        }

        // 5. Extract Next & Previous Chapter URLs
        var nextUrl: String? = null
        var prevUrl: String? = null

        val links = doc.select("a[href]")
        for (link in links) {
            val text = link.text().lowercase().trim()
            val rel = link.attr("rel").lowercase().trim()
            val className = link.className().lowercase().trim()
            val id = link.id().lowercase().trim()
            val absHref = link.absUrl("href").trim()

            if (absHref.isEmpty() || absHref == url || absHref.startsWith("javascript:")) continue

            // Check Next
            if (nextUrl == null) {
                if (rel == "next" ||
                    text == "next" || text == "next chapter" || text == "next chapter »" || text == "next »" ||
                    text.contains("next chapter") || text.contains("अगला") || text == "»" || text == ">" ||
                    className.contains("next") || id.contains("next")
                ) {
                    nextUrl = absHref
                }
            }

            // Check Prev
            if (prevUrl == null) {
                if (rel == "prev" || rel == "previous" ||
                    text == "prev" || text == "previous" || text == "« previous" || text == "« prev" ||
                    text.contains("prev chapter") || text.contains("पिछला") || text == "«" || text == "<" ||
                    className.contains("prev") || id.contains("prev")
                ) {
                    prevUrl = absHref
                }
            }
        }

        // 6. Extract Author & Cover image
        var author = doc.select("meta[name=author]").attr("content").trim()
        if (author.isEmpty()) {
            author = doc.select(".author, [itemprop=author]").text().trim()
        }
        if (author.isEmpty()) {
            author = "Unknown Author"
        }

        val coverImageUrl = doc.select("meta[property=og:image]").attr("content").trim().ifEmpty { null }

        return ExtractedChapter(
            novelTitle = novelTitle.take(120),
            chapterTitle = chapterTitle.take(120),
            chapterNumber = chapterNumber,
            content = content,
            nextChapterUrl = nextUrl,
            prevChapterUrl = prevUrl,
            author = author.take(80),
            sourceUrl = url,
            coverImageUrl = coverImageUrl
        )
    }

    private fun isAdOrNavigationParagraph(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("patreon") && lower.contains("support") ||
                lower.startsWith("chapter error") ||
                lower.startsWith("report chapter") ||
                lower.contains("sponsored by") ||
                lower.contains("click here to read next")
    }
}
