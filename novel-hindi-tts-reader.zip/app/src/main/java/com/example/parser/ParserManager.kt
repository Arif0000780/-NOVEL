package com.example.parser

import com.example.parser.adapters.RoyalRoadParser
import com.example.parser.adapters.WebnovelParser
import com.example.parser.adapters.WuxiaWorldParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class ParserManager(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {
    private val genericParser = GenericWebParser()
    private val adapters: List<WebsiteParser> = listOf(
        RoyalRoadParser(),
        WuxiaWorldParser(),
        WebnovelParser()
    )

    fun findParser(url: String): WebsiteParser {
        val matchingAdapter = adapters.firstOrNull { it.canParse(url) }
        return matchingAdapter ?: genericParser
    }

    suspend fun fetchAndExtract(url: String): Result<ExtractedChapter> = withContext(Dispatchers.IO) {
        try {
            // Validation
            if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                return@withContext Result.failure(IllegalArgumentException("Invalid URL: must start with http:// or https://"))
            }

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,hi;q=0.8")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP error ${response.code}: ${response.message}"))
            }

            val body = response.body?.string() ?: return@withContext Result.failure(Exception("Empty webpage response"))
            val parser = findParser(url)
            val extracted = parser.parse(body, url)

            if (extracted.content.isBlank()) {
                return@withContext Result.failure(Exception("No readable chapter text could be extracted from this page."))
            }

            Result.success(extracted)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun parseHtmlDirect(html: String, url: String): Result<ExtractedChapter> {
        return try {
            val parser = findParser(url)
            val extracted = parser.parse(html, url)
            Result.success(extracted)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
