package com.example.parser

interface WebsiteParser {
    val name: String
    fun canParse(url: String): Boolean
    fun parse(html: String, url: String): ExtractedChapter
}
