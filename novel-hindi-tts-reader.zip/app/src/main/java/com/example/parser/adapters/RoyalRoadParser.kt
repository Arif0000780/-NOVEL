package com.example.parser.adapters

import com.example.parser.ExtractedChapter
import com.example.parser.WebsiteParser
import org.jsoup.Jsoup
import java.util.regex.Pattern

class RoyalRoadParser : WebsiteParser {
    override val name: String = "Royal Road Adapter"

    override fun canParse(url: String): Boolean {
        return url.contains("royalroad.com")
    }

    override fun parse(html: String, url: String): ExtractedChapter {
        val doc = Jsoup.parse(html, url)
        val novelTitle = doc.select(".fic-header h1, h1[property=name]").text().trim().ifEmpty { "Royal Road Novel" }
        val chapterTitle = doc.select("h1.font-white, .chapter-inner h2").text().trim().ifEmpty { "Chapter" }

        var chapterNumber = 1
        val match = Pattern.compile("(?i)chapter[-_\\s]*(\\d+)").matcher(chapterTitle)
        if (match.find()) {
            chapterNumber = match.group(1)?.toIntOrNull() ?: 1
        }

        val chapterBody = doc.select(".chapter-inner.chapter-content").first()
        chapterBody?.select(".portlet, script, style, .author-note-portlet")?.remove()

        val content = chapterBody?.select("p")?.map { it.text().trim() }
            ?.filter { it.isNotEmpty() }
            ?.joinToString("\n\n") ?: (chapterBody?.text() ?: "")

        val nextUrl = doc.select("a.btn-primary:contains(Next), a:contains(Next Chapter)").firstOrNull()?.absUrl("href")
        val prevUrl = doc.select("a.btn-primary:contains(Prev), a:contains(Previous Chapter)").firstOrNull()?.absUrl("href")
        val author = doc.select(".author h4 a").text().trim().ifEmpty { "Unknown Author" }
        val coverUrl = doc.select(".thumbnail").attr("src").trim().ifEmpty { null }

        return ExtractedChapter(
            novelTitle = novelTitle,
            chapterTitle = chapterTitle,
            chapterNumber = chapterNumber,
            content = content,
            nextChapterUrl = nextUrl,
            prevChapterUrl = prevUrl,
            author = author,
            sourceUrl = url,
            coverImageUrl = coverUrl
        )
    }
}
