package com.example.parser.adapters

import com.example.parser.ExtractedChapter
import com.example.parser.WebsiteParser
import org.jsoup.Jsoup
import java.util.regex.Pattern

class WebnovelParser : WebsiteParser {
    override val name: String = "Webnovel Adapter"

    override fun canParse(url: String): Boolean {
        return url.contains("webnovel.com")
    }

    override fun parse(html: String, url: String): ExtractedChapter {
        val doc = Jsoup.parse(html, url)
        val novelTitle = doc.select(".cha-tit h3 a, .book-info h1").text().trim().ifEmpty { "Webnovel" }
        val chapterTitle = doc.select(".cha-tit h1, .chapter-title").text().trim().ifEmpty { "Chapter" }

        var chapterNumber = 1
        val match = Pattern.compile("(?i)(?:chapter|ch)[._\\s]*(\\d+)").matcher(chapterTitle)
        if (match.find()) {
            chapterNumber = match.group(1)?.toIntOrNull() ?: 1
        }

        val contentEl = doc.select(".cha-words, .chapter-content").first()
        contentEl?.select("script, style, .pirate, .author-say")?.remove()

        val content = contentEl?.select("p")?.map { it.text().trim() }
            ?.filter { it.isNotEmpty() }
            ?.joinToString("\n\n") ?: (contentEl?.text() ?: "")

        val nextUrl = doc.select("a.cha-next, a:contains(Next Chapter)").firstOrNull()?.absUrl("href")
        val prevUrl = doc.select("a.cha-prev, a:contains(Previous Chapter)").firstOrNull()?.absUrl("href")

        return ExtractedChapter(
            novelTitle = novelTitle,
            chapterTitle = chapterTitle,
            chapterNumber = chapterNumber,
            content = content,
            nextChapterUrl = nextUrl,
            prevChapterUrl = prevUrl,
            author = "Webnovel Author",
            sourceUrl = url
        )
    }
}
