package com.example.parser.adapters

import com.example.parser.ExtractedChapter
import com.example.parser.WebsiteParser
import org.jsoup.Jsoup
import java.util.regex.Pattern

class WuxiaWorldParser : WebsiteParser {
    override val name: String = "WuxiaWorld Adapter"

    override fun canParse(url: String): Boolean {
        return url.contains("wuxiaworld.com") || url.contains("novelfull.com")
    }

    override fun parse(html: String, url: String): ExtractedChapter {
        val doc = Jsoup.parse(html, url)
        val novelTitle = doc.select(".novel-title, .truyen-title, h1.title").text().trim().ifEmpty { "Wuxia World Novel" }
        val chapterTitle = doc.select(".chapter-title, h2.chapter-title").text().trim().ifEmpty { "Chapter" }

        var chapterNumber = 1
        val match = Pattern.compile("(?i)chapter[-_\\s]*(\\d+)").matcher(chapterTitle)
        if (match.find()) {
            chapterNumber = match.group(1)?.toIntOrNull() ?: 1
        }

        val contentEl = doc.select("#chapter-content, .chapter-content, #chr-content").first()
        contentEl?.select("script, style, .ads, [class*=ad-]")?.remove()

        val content = contentEl?.select("p")?.map { it.text().trim() }
            ?.filter { it.isNotEmpty() }
            ?.joinToString("\n\n") ?: (contentEl?.text() ?: "")

        val nextUrl = doc.select("#next_chap, a.btn-next, a:contains(Next Chapter)").firstOrNull()?.absUrl("href")
        val prevUrl = doc.select("#prev_chap, a.btn-prev, a:contains(Prev Chapter)").firstOrNull()?.absUrl("href")

        return ExtractedChapter(
            novelTitle = novelTitle,
            chapterTitle = chapterTitle,
            chapterNumber = chapterNumber,
            content = content,
            nextChapterUrl = nextUrl,
            prevChapterUrl = prevUrl,
            author = "Wuxia Author",
            sourceUrl = url
        )
    }
}
