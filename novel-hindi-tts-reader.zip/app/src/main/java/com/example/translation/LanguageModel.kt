package com.example.translation

data class SupportedLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val isAutoDetect: Boolean = false
) {
    val displayLabel: String
        get() = if (isAutoDetect) displayName else "$displayName ($nativeName)"
}

object LanguageRegistry {
    val AUTO_DETECT = SupportedLanguage(
        code = "auto",
        displayName = "Auto Detect",
        nativeName = "स्वतः पहचानें",
        isAutoDetect = true
    )

    val supportedLanguages: List<SupportedLanguage> = listOf(
        SupportedLanguage("en", "English", "English"),
        SupportedLanguage("hi", "Hindi", "हिन्दी"),
        SupportedLanguage("ur", "Urdu", "اردو"),
        SupportedLanguage("ar", "Arabic", "العربية"),
        SupportedLanguage("bn", "Bengali", "বাংলা"),
        SupportedLanguage("ta", "Tamil", "தமிழ்"),
        SupportedLanguage("te", "Telugu", "తెలుగు"),
        SupportedLanguage("mr", "Marathi", "मराठी"),
        SupportedLanguage("gu", "Gujarati", "ગુજરાતી"),
        SupportedLanguage("pa", "Punjabi", "ਪੰਜਾਬੀ"),
        SupportedLanguage("fr", "French", "Français"),
        SupportedLanguage("de", "German", "Deutsch"),
        SupportedLanguage("es", "Spanish", "Español"),
        SupportedLanguage("zh-CN", "Chinese", "中文"),
        SupportedLanguage("ja", "Japanese", "日本語"),
        SupportedLanguage("ko", "Korean", "한국어"),
        SupportedLanguage("ru", "Russian", "Русский"),
        SupportedLanguage("pt", "Portuguese", "Português"),
        SupportedLanguage("it", "Italian", "Italiano"),
        SupportedLanguage("tr", "Turkish", "Türkçe"),
        SupportedLanguage("ne", "Nepali", "नेपाली"),
        SupportedLanguage("sa", "Sanskrit", "संस्कृतम्")
    )

    val sourceLanguages: List<SupportedLanguage> = listOf(AUTO_DETECT) + supportedLanguages
    val targetLanguages: List<SupportedLanguage> = supportedLanguages

    fun fromCode(code: String): SupportedLanguage {
        if (code.equals("auto", ignoreCase = true)) return AUTO_DETECT
        return supportedLanguages.firstOrNull { it.code.equals(code, ignoreCase = true) }
            ?: SupportedLanguage(code, code.uppercase(), code)
    }
}
