package com.example.translation

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class LanguageOption(
    val code: String,
    val name: String,
    val nativeName: String,
    val ttsLanguageTag: String,
    val isAuto: Boolean = false
) {
    val displayLabel: String
        get() = if (isAuto) name else "$name ($nativeName)"
}

object SupportedLanguages {
    val SOURCE_LANGUAGES = listOf(
        LanguageOption("auto", "Auto Detect", "पहचानें", "hi", true),
        LanguageOption("en", "English", "English", "en"),
        LanguageOption("hi", "Hindi", "हिन्दी", "hi"),
        LanguageOption("ur", "Urdu", "اردو", "ur"),
        LanguageOption("ar", "Arabic", "العربية", "ar"),
        LanguageOption("bn", "Bengali", "বাংলা", "bn"),
        LanguageOption("ta", "Tamil", "தமிழ்", "ta"),
        LanguageOption("te", "Telugu", "తెలుగు", "te"),
        LanguageOption("mr", "Marathi", "मराठी", "mr"),
        LanguageOption("gu", "Gujarati", "ગુજરાતી", "gu"),
        LanguageOption("pa", "Punjabi", "ਪੰਜਾਬੀ", "pa"),
        LanguageOption("fr", "French", "Français", "fr"),
        LanguageOption("de", "German", "Deutsch", "de"),
        LanguageOption("es", "Spanish", "Español", "es"),
        LanguageOption("zh-CN", "Chinese", "中文", "zh"),
        LanguageOption("ja", "Japanese", "日本語", "ja"),
        LanguageOption("ko", "Korean", "한국어", "ko"),
        LanguageOption("ru", "Russian", "Русский", "ru"),
        LanguageOption("pt", "Portuguese", "Português", "pt"),
        LanguageOption("it", "Italian", "Italiano", "it")
    )

    val TARGET_LANGUAGES = listOf(
        LanguageOption("hi", "Hindi", "हिन्दी", "hi"),
        LanguageOption("en", "English", "English", "en"),
        LanguageOption("ur", "Urdu", "اردو", "ur"),
        LanguageOption("ar", "Arabic", "العربية", "ar"),
        LanguageOption("bn", "Bengali", "বাংলা", "bn"),
        LanguageOption("ta", "Tamil", "தமிழ்", "ta"),
        LanguageOption("te", "Telugu", "తెలుగు", "te"),
        LanguageOption("mr", "Marathi", "मराठी", "mr"),
        LanguageOption("gu", "Gujarati", "ગુજરાતી", "gu"),
        LanguageOption("pa", "Punjabi", "ਪੰਜਾਬੀ", "pa"),
        LanguageOption("fr", "French", "Français", "fr"),
        LanguageOption("de", "German", "Deutsch", "de"),
        LanguageOption("es", "Spanish", "Español", "es"),
        LanguageOption("zh-CN", "Chinese", "中文", "zh"),
        LanguageOption("ja", "Japanese", "日本語", "ja"),
        LanguageOption("ko", "Korean", "한국어", "ko"),
        LanguageOption("ru", "Russian", "Русский", "ru"),
        LanguageOption("pt", "Portuguese", "Português", "pt"),
        LanguageOption("it", "Italian", "Italiano", "it")
    )

    fun findLanguage(code: String): LanguageOption {
        return SOURCE_LANGUAGES.firstOrNull { it.code.equals(code, ignoreCase = true) }
            ?: TARGET_LANGUAGES.firstOrNull { it.code.equals(code, ignoreCase = true) }
            ?: LanguageOption(code, code.uppercase(), code.uppercase(), code)
    }
}

object NormalTranslationEngine {
    private const val TAG = "NormalTranslationEngine"

    /**
     * Translates complete text preserving all paragraphs and line breaks.
     * Splits long text into safe chunks if necessary, translates every chunk,
     * and combines all translated chunks in the exact original order.
     */
    suspend fun translateCompleteText(
        text: String,
        sourceLang: String,
        targetLang: String,
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<String> = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.success("")
        }

        // Same source and target (when not auto)
        if (sourceLang != "auto" && sourceLang.equals(targetLang, ignoreCase = true)) {
            return@withContext Result.success(text)
        }

        try {
            // Split into paragraphs preserving paragraph breaks (\n\n or \r\n\r\n)
            val paragraphs = text.split(Regex("(\r?\n){2,}"))
            val translatedParagraphs = mutableListOf<String>()

            val totalParagraphs = paragraphs.size
            for ((index, para) in paragraphs.withIndex()) {
                val paraTrimmed = para.trim()
                if (paraTrimmed.isEmpty()) {
                    translatedParagraphs.add("")
                    continue
                }

                onProgress(index + 1, totalParagraphs)

                // Preserve internal single line breaks within this paragraph
                val lines = para.split(Regex("\r?\n"))
                val translatedLines = mutableListOf<String>()

                for (line in lines) {
                    val lineTrimmed = line.trim()
                    if (lineTrimmed.isEmpty()) {
                        translatedLines.add("")
                        continue
                    }

                    // If a single line is long (> 1000 chars), split into sentence chunks
                    if (lineTrimmed.length > 1000) {
                        val chunks = splitIntoSentenceChunks(lineTrimmed, maxChunkSize = 800)
                        val translatedChunks = mutableListOf<String>()
                        for (chunk in chunks) {
                            val trans = translateChunkPost(chunk, sourceLang, targetLang)
                            translatedChunks.add(trans)
                        }
                        translatedLines.add(translatedChunks.joinToString(" "))
                    } else {
                        val trans = translateChunkPost(lineTrimmed, sourceLang, targetLang)
                        translatedLines.add(trans)
                    }
                }

                translatedParagraphs.add(translatedLines.joinToString("\n"))
            }

            val finalOutput = translatedParagraphs.joinToString("\n\n")
            if (finalOutput.isBlank() && text.isNotBlank()) {
                Result.failure(Exception("Translation returned empty result. Please check your internet connection."))
            } else {
                Result.success(finalOutput)
            }
        } catch (e: Exception) {
            try {
                Log.e(TAG, "Translation error: ${e.message}", e)
            } catch (_: Throwable) {}
            Result.failure(Exception(e.localizedMessage ?: "Translation failed. Please check internet connection."))
        }
    }

    private fun splitIntoSentenceChunks(text: String, maxChunkSize: Int): List<String> {
        val sentences = text.split(Regex("(?<=[.?!।\n])\\s+"))
        val chunks = mutableListOf<String>()
        var currentChunk = StringBuilder()

        for (sentence in sentences) {
            if (currentChunk.length + sentence.length + 1 > maxChunkSize) {
                if (currentChunk.isNotEmpty()) {
                    chunks.add(currentChunk.toString().trim())
                    currentChunk = StringBuilder()
                }
                // Handle an individual sentence longer than maxChunkSize
                if (sentence.length > maxChunkSize) {
                    val words = sentence.split(" ")
                    var wordChunk = StringBuilder()
                    for (word in words) {
                        if (wordChunk.length + word.length + 1 > maxChunkSize) {
                            chunks.add(wordChunk.toString().trim())
                            wordChunk = StringBuilder()
                        }
                        if (wordChunk.isNotEmpty()) wordChunk.append(" ")
                        wordChunk.append(word)
                    }
                    if (wordChunk.isNotEmpty()) {
                        chunks.add(wordChunk.toString().trim())
                    }
                } else {
                    currentChunk.append(sentence)
                }
            } else {
                if (currentChunk.isNotEmpty()) currentChunk.append(" ")
                currentChunk.append(sentence)
            }
        }
        if (currentChunk.isNotEmpty()) {
            chunks.add(currentChunk.toString().trim())
        }
        return chunks
    }

    /**
     * Translates a single chunk using Google Translate's endpoint via HTTP POST.
     * HTTP POST avoids URL length restrictions for long sentences/chunks.
     */
    private fun translateChunkPost(chunk: String, sourceLang: String, targetLang: String): String {
        val sl = if (sourceLang.isBlank()) "auto" else sourceLang
        val tl = if (targetLang.isBlank()) "hi" else targetLang

        val postData = "q=" + URLEncoder.encode(chunk, "UTF-8")
        val endpoint = "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=$sl&tl=$tl&dt=t"

        val url = URL(endpoint)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36")
            setRequestProperty("Accept", "*/*")
        }

        conn.outputStream.use { os ->
            OutputStreamWriter(os, "UTF-8").use { writer ->
                writer.write(postData)
                writer.flush()
            }
        }

        val code = conn.responseCode
        if (code == 200) {
            val reader = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8"))
            val responseText = reader.use { it.readText() }
            val rootArray = JSONArray(responseText)
            if (rootArray.length() > 0 && !rootArray.isNull(0)) {
                val sentencesArray = rootArray.getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until sentencesArray.length()) {
                    val sentenceItem = sentencesArray.optJSONArray(i)
                    if (sentenceItem != null && sentenceItem.length() > 0 && !sentenceItem.isNull(0)) {
                        val part = sentenceItem.optString(0, "")
                        sb.append(part)
                    }
                }
                val translated = sb.toString().trim()
                if (translated.isNotEmpty()) {
                    return translated
                }
            }
        }

        // Fallback to GET if POST somehow receives non-200
        return translateChunkGet(chunk, sl, tl)
    }

    private fun translateChunkGet(chunk: String, sl: String, tl: String): String {
        val encodedQuery = URLEncoder.encode(chunk, "UTF-8")
        val endpoint = "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=$sl&tl=$tl&dt=t&q=$encodedQuery"

        val url = URL(endpoint)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36")
            setRequestProperty("Accept", "*/*")
        }

        val code = conn.responseCode
        if (code == 200) {
            val reader = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8"))
            val responseText = reader.use { it.readText() }
            val rootArray = JSONArray(responseText)
            if (rootArray.length() > 0 && !rootArray.isNull(0)) {
                val sentencesArray = rootArray.getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until sentencesArray.length()) {
                    val sentenceItem = sentencesArray.optJSONArray(i)
                    if (sentenceItem != null && sentenceItem.length() > 0 && !sentenceItem.isNull(0)) {
                        val part = sentenceItem.optString(0, "")
                        sb.append(part)
                    }
                }
                val translated = sb.toString().trim()
                if (translated.isNotEmpty()) {
                    return translated
                }
            }
        }
        throw Exception("Translation server returned HTTP $code")
    }
}
