package com.example.translation

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

fun isPureHindi(text: String): Boolean {
    val trimmed = text.trim()
    if (trimmed.isEmpty()) return false
    val devanagariCount = trimmed.count { it in '\u0900'..'\u097F' }
    val latinCount = trimmed.count { (it in 'a'..'z') || (it in 'A'..'Z') }
    val totalLetters = devanagariCount + latinCount
    if (totalLetters == 0) return devanagariCount > 0
    return (devanagariCount.toFloat() / totalLetters) >= 0.70f
}

class ChunkedTranslationHelper {
    fun splitIntoParagraphChunks(text: String, maxChunkSize: Int = 1800): List<String> {
        val paragraphs = text.split(Regex("\n\n+"))
        val chunks = mutableListOf<String>()
        var currentChunk = StringBuilder()

        for (p in paragraphs) {
            val trimmed = p.trim()
            if (trimmed.isEmpty()) continue

            if (currentChunk.isNotEmpty() && currentChunk.length + trimmed.length + 2 > maxChunkSize) {
                chunks.add(currentChunk.toString().trim())
                currentChunk = StringBuilder()
            }
            if (currentChunk.isNotEmpty()) {
                currentChunk.append("\n\n")
            }
            currentChunk.append(trimmed)
        }
        if (currentChunk.isNotEmpty()) {
            chunks.add(currentChunk.toString().trim())
        }
        return if (chunks.isEmpty()) listOf(text) else chunks
    }
}

class PureHindiTranslationService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
) : TranslationService {
    override val providerName: String = "Neural Hindi Translation Engine"

    override suspend fun translate(
        text: String,
        sourceLanguage: String,
        targetLanguage: String,
        style: TranslationStyle
    ): Result<String> = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.success("")
        }

        try {
            // Split complete chapter into paragraphs by double newlines (\n\n)
            val paragraphs = text.split("\n\n")
            val translatedParagraphs = mutableListOf<String>()

            for (paragraph in paragraphs) {
                val trimmedPara = paragraph.trim()
                if (trimmedPara.isEmpty()) {
                    translatedParagraphs.add("")
                    continue
                }

                // If paragraph is already pure Hindi, keep it
                if (isPureHindi(trimmedPara)) {
                    translatedParagraphs.add(trimmedPara)
                    continue
                }

                // Split paragraph lines by single newline (\n)
                val lines = trimmedPara.split("\n")
                val translatedLines = mutableListOf<String>()

                for (line in lines) {
                    val trimmedLine = line.trim()
                    if (trimmedLine.isEmpty()) {
                        translatedLines.add("")
                        continue
                    }

                    if (isPureHindi(trimmedLine)) {
                        translatedLines.add(trimmedLine)
                        continue
                    }

                    // For long paragraphs or lines (> 800 chars), split into sentence chunks
                    if (trimmedLine.length > 800) {
                        val sentences = splitIntoSentences(trimmedLine, maxChunkSize = 700)
                        val translatedSentences = mutableListOf<String>()
                        for (sentence in sentences) {
                            val trans = translateChunkPost(sentence)
                            translatedSentences.add(trans)
                        }
                        translatedLines.add(translatedSentences.joinToString(" "))
                    } else {
                        val trans = translateChunkPost(trimmedLine)
                        translatedLines.add(trans)
                    }
                }

                translatedParagraphs.add(translatedLines.joinToString("\n"))
            }

            val finalOutput = translatedParagraphs.joinToString("\n\n")
            if (finalOutput.isBlank() && text.isNotBlank()) {
                Result.failure(Exception("Translation returned empty text"))
            } else if (!isPureHindi(finalOutput)) {
                Result.failure(Exception("Could not generate complete Hindi translation. Please check connection."))
            } else {
                Result.success(finalOutput)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Hindi translation failed: ${e.localizedMessage ?: "Network error"}", e))
        }
    }

    private fun splitIntoSentences(text: String, maxChunkSize: Int): List<String> {
        val sentences = text.split(Regex("(?<=[.?!।\n])\\s+"))
        val chunks = mutableListOf<String>()
        var current = StringBuilder()

        for (s in sentences) {
            val sentence = s.trim()
            if (sentence.isEmpty()) continue
            if (current.length + sentence.length + 1 > maxChunkSize) {
                if (current.isNotEmpty()) {
                    chunks.add(current.toString().trim())
                    current = StringBuilder()
                }
                current.append(sentence)
            } else {
                if (current.isNotEmpty()) current.append(" ")
                current.append(sentence)
            }
        }
        if (current.isNotEmpty()) {
            chunks.add(current.toString().trim())
        }
        return if (chunks.isEmpty()) listOf(text) else chunks
    }

    private fun translateChunkPost(chunk: String): String {
        val postData = "q=" + URLEncoder.encode(chunk, "UTF-8")
        val endpoint = "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=auto&tl=hi&dt=t"
        val requestBody = postData.toRequestBody("application/x-www-form-urlencoded; charset=UTF-8".toMediaType())

        val request = Request.Builder()
            .url(endpoint)
            .post(requestBody)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36")
            .header("Accept", "*/*")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Translation service returned HTTP ${response.code}")
            }
            val bodyString = response.body?.string()
                ?: throw IllegalStateException("Empty response from translation service")
            return parseTranslationResponse(bodyString)
        }
    }

    private fun parseTranslationResponse(jsonString: String): String {
        val root = JSONArray(jsonString)
        if (root.length() == 0 || root.isNull(0)) return ""

        val sentencesArray = root.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until sentencesArray.length()) {
            val item = sentencesArray.optJSONArray(i)
            if (item != null && item.length() > 0 && !item.isNull(0)) {
                sb.append(item.getString(0))
            }
        }
        return sb.toString()
    }
}

typealias SmartHindiTranslator = PureHindiTranslationService

class GeminiTranslationService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .build()
) : TranslationService {
    override val providerName: String = "Gemini AI Neural Hindi"

    override suspend fun translate(
        text: String,
        sourceLanguage: String,
        targetLanguage: String,
        style: TranslationStyle
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String ?: ""
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("No Gemini API key found"))
        }

        try {
            val helper = ChunkedTranslationHelper()
            val chunks = helper.splitIntoParagraphChunks(text, 2500)
            val translatedChunks = mutableListOf<String>()

            val styleInstruction = when (style) {
                TranslationStyle.NATURAL -> "natural, fluent, idiomatic Hindi with modern novel phrasing"
                TranslationStyle.SIMPLE -> "simple, easy to understand conversational Hindi"
                TranslationStyle.LITERARY -> "formal, poetic, and classic literary Hindi with rich vocabulary"
            }

            for (chunk in chunks) {
                val prompt = """
                    Translate the following novel text into high-quality $styleInstruction.
                    Rules:
                    1. Maintain paragraph breaks exactly.
                    2. Keep character dialogue vivid and expressive.
                    3. Preserve character names and titles accurately in Hindi script.
                    4. Do not summarize or skip sentences.
                    5. Output ONLY the translated Hindi text.

                    Text to translate:
                    $chunk
                """.trimIndent()

                val requestJson = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().put("text", prompt))
                            })
                        })
                    })
                    put("generationConfig", JSONObject().apply {
                        put("temperature", 0.3)
                    })
                }

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Gemini API returned error: ${response.code}"))
                }

                val bodyStr = response.body?.string() ?: return@withContext Result.failure(Exception("Empty response"))
                val json = JSONObject(bodyStr)
                val candidates = json.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val translatedText = parts?.optJSONObject(0)?.optString("text")?.trim() ?: ""
                    translatedChunks.add(translatedText)
                } else {
                    return@withContext Result.failure(Exception("No translation candidate received"))
                }
            }

            Result.success(translatedChunks.joinToString("\n\n"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class CompositeTranslationManager(
    private val smartTranslator: SmartHindiTranslator = SmartHindiTranslator(),
    private val geminiTranslator: GeminiTranslationService = GeminiTranslationService()
) {
    suspend fun translateNovelText(
        text: String,
        style: TranslationStyle = TranslationStyle.NATURAL,
        providerPreference: String = "SMART_LOCAL"
    ): Result<String> {
        // If user prefers Gemini AI, try it first; if it fails or key missing, fallback to neural Hindi translator
        if (providerPreference == "GEMINI_AI") {
            val geminiResult = geminiTranslator.translate(text, "auto", "hi", style)
            if (geminiResult.isSuccess && isPureHindi(geminiResult.getOrNull() ?: "")) {
                return geminiResult
            }
        }

        // Default: Pure Hindi paragraph-by-paragraph translation
        return smartTranslator.translate(text, "auto", "hi", style)
    }
}
