package com.example.translation

enum class TranslationStyle(val displayName: String, val description: String) {
    NATURAL("Natural Hindi", "प्राकृतिक और बोलचाल की हिंदी"),
    SIMPLE("Simple Hindi", "सरल और स्पष्ट हिंदी"),
    LITERARY("Literary Hindi", "गंभीर एवं साहित्यिक हिंदी")
}

interface TranslationService {
    val providerName: String
    suspend fun translate(
        text: String,
        sourceLanguage: String = "auto",
        targetLanguage: String = "hi",
        style: TranslationStyle = TranslationStyle.NATURAL
    ): Result<String>
}
