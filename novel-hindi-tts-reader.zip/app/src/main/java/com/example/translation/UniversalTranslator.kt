package com.example.translation

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class UniversalTranslator(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
) {

    companion object {
        private const val TAG = "UniversalTranslator"
    }

    /**
     * Translates complete multiline text between source and target languages.
     * Preserves all paragraph breaks (\n\n) and single line breaks (\n).
     * Splits long text into safe chunks and combines them in original order.
     */
    suspend fun translateText(
        text: String,
        sourceLangCode: String,
        targetLangCode: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.success("")
        }

        // If source and target are identical (and not auto), return source directly
        if (!sourceLangCode.equals("auto", ignoreCase = true) &&
            sourceLangCode.equals(targetLangCode, ignoreCase = true)
        ) {
            return@withContext Result.success(text)
        }

        try {
            // Split paragraphs by double newlines (\n\n) to preserve paragraph structure
            val paragraphs = text.split("\n\n")
            val translatedParagraphs = mutableListOf<String>()

            for (paragraph in paragraphs) {
                // Check if paragraph contains multiple lines (\n)
                val lines = paragraph.split("\n")
                val translatedLines = mutableListOf<String>()

                for (line in lines) {
                    val lineTrimmed = line.trim()
                    if (lineTrimmed.isEmpty()) {
                        translatedLines.add("")
                        continue
                    }

                    // If a single line is excessively long (> 1200 chars), split by sentences
                    if (lineTrimmed.length > 1200) {
                        val sentenceChunks = splitIntoSentenceChunks(lineTrimmed, maxChunkSize = 1000)
                        val translatedSentenceChunks = mutableListOf<String>()
                        for (sChunk in sentenceChunks) {
                            val trans = translateSingleChunk(sChunk, sourceLangCode, targetLangCode)
                            translatedSentenceChunks.add(trans)
                        }
                        translatedLines.add(translatedSentenceChunks.joinToString(" "))
                    } else {
                        val trans = translateSingleChunk(lineTrimmed, sourceLangCode, targetLangCode)
                        translatedLines.add(trans)
                    }
                }

                translatedParagraphs.add(translatedLines.joinToString("\n"))
            }

            val finalResult = translatedParagraphs.joinToString("\n\n")
            Result.success(finalResult)
        } catch (e: Exception) {
            Log.e(TAG, "Translation error: ${e.message}", e)
            Result.failure(Exception("Translation failed: ${e.localizedMessage ?: "Network or service error"}", e))
        }
    }

    private fun splitIntoSentenceChunks(text: String, maxChunkSize: Int): List<String> {
        val sentences = text.split(Regex("(?<=[.!?।])\\s+"))
        val chunks = mutableListOf<String>()
        var currentChunk = StringBuilder()

        for (s in sentences) {
            val sentence = s.trim()
            if (sentence.isEmpty()) continue

            if (currentChunk.isNotEmpty() && currentChunk.length + sentence.length + 1 > maxChunkSize) {
                chunks.add(currentChunk.toString().trim())
                currentChunk = StringBuilder()
            }
            if (currentChunk.isNotEmpty()) {
                currentChunk.append(" ")
            }
            currentChunk.append(sentence)
        }
        if (currentChunk.isNotEmpty()) {
            chunks.add(currentChunk.toString().trim())
        }
        return if (chunks.isEmpty()) listOf(text) else chunks
    }

    private fun translateSingleChunk(
        chunk: String,
        sourceLangCode: String,
        targetLangCode: String
    ): String {
        val encodedQuery = URLEncoder.encode(chunk, "UTF-8")
        val sl = if (sourceLangCode.isBlank() || sourceLangCode.equals("auto", ignoreCase = true)) "auto" else sourceLangCode
        val tl = if (targetLangCode.isBlank()) "hi" else targetLangCode

        val url = "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=$sl&tl=$tl&dt=t&q=$encodedQuery"

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Server returned HTTP ${response.code}")
            }
            val bodyString = response.body?.string()
                ?: throw IllegalStateException("Empty response from translation service")
            return parseTranslationResponse(bodyString)
        }
    }

    private fun parseTranslationResponse(jsonString: String): String {
        val root = JSONArray(jsonString)
        if (root.length() == 0 || root.isNull(0)) return ""

        val sentencesArray = root.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until sentencesArray.length()) {
            val item = sentencesArray.optJSONArray(i)
            if (item != null && item.length() > 0 && !item.isNull(0)) {
                sb.append(item.getString(0))
            }
        }
        return sb.toString()
    }
}
