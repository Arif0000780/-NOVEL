package com.example.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.translation.isPureHindi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class HindiTtsEngine(
    private val context: Context,
    private val onInitComplete: (Boolean) -> Unit = {}
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    var isInitialized: Boolean = false
        private set

    private var paragraphs: List<String> = emptyList()
    var currentParagraphIndex: Int = 0
        private set

    private var currentRate: Float = 1.0f
    private var currentPitch: Float = 1.0f
    private var selectedVoiceName: String? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _currentParagraph = MutableStateFlow(0)
    val currentParagraph: StateFlow<Int> = _currentParagraph.asStateFlow()

    private val _totalParagraphs = MutableStateFlow(0)
    val totalParagraphs: StateFlow<Int> = _totalParagraphs.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    var onChapterFinished: (() -> Unit)? = null
    var onParagraphChanged: ((Int) -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Try generic Hindi
                val altResult = tts?.setLanguage(Locale("hi"))
                if (altResult == TextToSpeech.LANG_MISSING_DATA || altResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    _statusMessage.value = "Hindi voice not pre-installed. Using system default voice."
                    tts?.language = Locale.getDefault()
                }
            }

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                    _isPaused.value = false
                }

                override fun onDone(utteranceId: String?) {
                    val nextIdx = currentParagraphIndex + 1
                    if (nextIdx < paragraphs.size) {
                        currentParagraphIndex = nextIdx
                        _currentParagraph.value = nextIdx
                        onParagraphChanged?.invoke(nextIdx)
                        speakCurrentParagraph()
                    } else {
                        // Chapter finished
                        _isPlaying.value = false
                        _isPaused.value = false
                        onChapterFinished?.invoke()
                    }
                }

                override fun onError(utteranceId: String?) {
                    _statusMessage.value = "Speech playback error on paragraph ${currentParagraphIndex + 1}"
                }
            })

            isInitialized = true
            applySpeedAndPitch()
            onInitComplete(true)
        } else {
            isInitialized = false
            _statusMessage.value = "TTS engine initialization failed"
            onInitComplete(false)
        }
    }

    fun getInstalledHindiVoices(): List<Voice> {
        val allVoices = try {
            tts?.voices ?: emptySet()
        } catch (e: Exception) {
            emptySet()
        }
        return allVoices.filter {
            it.locale.language == "hi" || it.name.contains("hi-", ignoreCase = true)
        }.sortedBy { it.name }
    }

    fun setVoiceByName(voiceName: String) {
        selectedVoiceName = voiceName
        val voice = getInstalledHindiVoices().firstOrNull { it.name == voiceName }
        if (voice != null) {
            tts?.voice = voice
        }
    }

    fun setSpeed(speed: Float): Boolean {
        currentRate = speed.coerceIn(0.5f, 5.0f)
        return try {
            val res = tts?.setSpeechRate(currentRate)
            if (res == TextToSpeech.ERROR && currentRate > 3.0f) {
                // If engine refuses rates > 3.0x, clamp to 3.0x gracefully
                currentRate = 3.0f
                tts?.setSpeechRate(3.0f)
                _statusMessage.value = "Device TTS engine capped rate at 3.0x"
                false
            } else {
                true
            }
        } catch (e: Exception) {
            currentRate = 1.0f
            tts?.setSpeechRate(1.0f)
            false
        }
    }

    fun setPitch(pitch: Float) {
        currentPitch = pitch.coerceIn(0.5f, 2.0f)
        tts?.setPitch(currentPitch)
    }

    private fun applySpeedAndPitch() {
        tts?.let {
            it.setSpeechRate(currentRate)
            it.setPitch(currentPitch)
        }
    }

    fun loadContent(text: String, startIndex: Int = 0) {
        val raw = text.split("\n\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }
        // Ensure only fully translated pure Hindi paragraphs are spoken
        val pureHindiParas = raw.filter { isPureHindi(it) }
        paragraphs = pureHindiParas
        _totalParagraphs.value = paragraphs.size
        currentParagraphIndex = startIndex.coerceIn(0, (paragraphs.size - 1).coerceAtLeast(0))
        _currentParagraph.value = currentParagraphIndex
    }

    fun play() {
        if (paragraphs.isEmpty()) return
        _isPaused.value = false
        speakCurrentParagraph()
    }

    fun pause() {
        tts?.stop()
        _isPlaying.value = false
        _isPaused.value = true
    }

    fun resume() {
        if (_isPaused.value) {
            play()
        }
    }

    fun stop() {
        tts?.stop()
        _isPlaying.value = false
        _isPaused.value = false
    }

    fun nextParagraph() {
        if (currentParagraphIndex < paragraphs.size - 1) {
            currentParagraphIndex++
            _currentParagraph.value = currentParagraphIndex
            onParagraphChanged?.invoke(currentParagraphIndex)
            if (_isPlaying.value) {
                speakCurrentParagraph()
            }
        }
    }

    fun prevParagraph() {
        if (currentParagraphIndex > 0) {
            currentParagraphIndex--
            _currentParagraph.value = currentParagraphIndex
            onParagraphChanged?.invoke(currentParagraphIndex)
            if (_isPlaying.value) {
                speakCurrentParagraph()
            }
        }
    }

    fun seekToParagraph(index: Int) {
        if (index in paragraphs.indices) {
            currentParagraphIndex = index
            _currentParagraph.value = currentParagraphIndex
            onParagraphChanged?.invoke(currentParagraphIndex)
            if (_isPlaying.value) {
                speakCurrentParagraph()
            }
        }
    }

    private fun speakCurrentParagraph() {
        if (currentParagraphIndex !in paragraphs.indices) return
        val textToSpeak = paragraphs[currentParagraphIndex]
        if (!isPureHindi(textToSpeak)) return
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "para_$currentParagraphIndex")
        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params, "para_$currentParagraphIndex")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
