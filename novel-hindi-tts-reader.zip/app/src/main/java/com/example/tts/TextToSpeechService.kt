package com.example.tts

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Android Service implementing TextToSpeech engine playback.
 * Supports:
 * - Configurable speech rate from 0.5x to 5.0x
 * - Play / Pause / Resume / Stop controls
 * - Paragraph tracking and sequential playback
 * - Audio focus management
 * - Bound (LocalBinder) and Started (Intent) service operation
 * - Foreground notification with media playback controls
 */
class TextToSpeechService : Service(), TextToSpeech.OnInitListener {

    enum class PlaybackState {
        IDLE,
        INITIALIZING,
        PLAYING,
        PAUSED,
        STOPPED,
        ERROR
    }

    inner class LocalBinder : Binder() {
        val service: TextToSpeechService get() = this@TextToSpeechService
    }

    private val binder = LocalBinder()
    private var textToSpeech: TextToSpeech? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    // Playback state & observables
    private val _playbackState = MutableStateFlow(PlaybackState.INITIALIZING)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _pitch = MutableStateFlow(1.0f)
    val pitch: StateFlow<Float> = _pitch.asStateFlow()

    private val _currentParagraphIndex = MutableStateFlow(0)
    val currentParagraphIndex: StateFlow<Int> = _currentParagraphIndex.asStateFlow()

    private val _totalParagraphs = MutableStateFlow(0)
    val totalParagraphs: StateFlow<Int> = _totalParagraphs.asStateFlow()

    private val _currentUtteranceId = MutableStateFlow<String?>(null)
    val currentUtteranceId: StateFlow<String?> = _currentUtteranceId.asStateFlow()

    private val _title = MutableStateFlow("Text to Speech")
    val title: StateFlow<String> = _title.asStateFlow()

    private val _subtitle = MutableStateFlow("")
    val subtitle: StateFlow<String> = _subtitle.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Internal playlist / content
    private val paragraphs = mutableListOf<String>()
    private var isEngineReady = false
    private var pendingAutoPlay = false

    // Listeners / callbacks
    var onPlaybackStateChanged: ((PlaybackState) -> Unit)? = null
    var onParagraphCompleted: ((index: Int, total: Int) -> Unit)? = null
    var onContentFinished: (() -> Unit)? = null

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        createNotificationChannel()
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        _playbackState.value = PlaybackState.INITIALIZING
        textToSpeech = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val tts = textToSpeech
            if (tts != null) {
                // Configure preferred locale: Hindi if supported, else default locale
                val hindiLocale = Locale("hi", "IN")
                val langResult = tts.setLanguage(hindiLocale)
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val genericHindi = Locale("hi")
                    val altResult = tts.setLanguage(genericHindi)
                    if (altResult == TextToSpeech.LANG_MISSING_DATA || altResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts.language = Locale.getDefault()
                    }
                }

                // Setup UtteranceProgressListener
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _currentUtteranceId.value = utteranceId
                        updatePlaybackState(PlaybackState.PLAYING)
                        updateForegroundNotification()
                    }

                    override fun onDone(utteranceId: String?) {
                        val currentIdx = _currentParagraphIndex.value
                        val total = paragraphs.size
                        onParagraphCompleted?.invoke(currentIdx, total)

                        val nextIdx = currentIdx + 1
                        if (nextIdx < total) {
                            _currentParagraphIndex.value = nextIdx
                            speakParagraph(nextIdx)
                        } else {
                            // All paragraphs completed
                            updatePlaybackState(PlaybackState.STOPPED)
                            abandonAudioFocus()
                            updateForegroundNotification()
                            onContentFinished?.invoke()
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        _errorMessage.value = "Playback error occurred for utterance: $utteranceId"
                        updatePlaybackState(PlaybackState.ERROR)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _errorMessage.value = "Playback error ($errorCode) for utterance: $utteranceId"
                        updatePlaybackState(PlaybackState.ERROR)
                    }
                })

                // Apply initial speech rate and pitch
                applySpeechRate(_speechRate.value)
                applyPitch(_pitch.value)

                isEngineReady = true
                updatePlaybackState(PlaybackState.IDLE)

                if (pendingAutoPlay) {
                    pendingAutoPlay = false
                    play()
                }
            }
        } else {
            isEngineReady = false
            _errorMessage.value = "Failed to initialize Android TextToSpeech engine (status: $status)"
            updatePlaybackState(PlaybackState.ERROR)
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val incomingTitle = intent?.getStringExtra(EXTRA_TITLE)
        val incomingSubtitle = intent?.getStringExtra(EXTRA_SUBTITLE)
        val textToSpeak = intent?.getStringExtra(EXTRA_TEXT)
        val targetRate = intent?.getFloatExtra(EXTRA_SPEECH_RATE, -1f) ?: -1f

        if (!incomingTitle.isNullOrBlank()) _title.value = incomingTitle
        if (!incomingSubtitle.isNullOrBlank()) _subtitle.value = incomingSubtitle

        if (!textToSpeak.isNullOrBlank()) {
            setText(textToSpeak)
        }

        if (targetRate in MIN_SPEECH_RATE..MAX_SPEECH_RATE) {
            setSpeechRate(targetRate)
        }

        when (action) {
            ACTION_PLAY -> play()
            ACTION_PAUSE -> pause()
            ACTION_RESUME -> resume()
            ACTION_STOP -> stop()
            ACTION_NEXT -> next()
            ACTION_PREVIOUS -> previous()
            ACTION_SET_RATE -> {
                if (targetRate > 0) setSpeechRate(targetRate)
            }
        }

        return START_NOT_STICKY
    }

    // =========================================================================
    // Core Playback Controls
    // =========================================================================

    /**
     * Loads text content into paragraphs for sequential reading.
     */
    fun setText(text: String, startIndex: Int = 0) {
        val splitList = text.split("\n\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }

        synchronized(paragraphs) {
            paragraphs.clear()
            if (splitList.isEmpty()) {
                if (text.isNotBlank()) paragraphs.add(text.trim())
            } else {
                paragraphs.addAll(splitList)
            }
        }

        _totalParagraphs.value = paragraphs.size
        _currentParagraphIndex.value = startIndex.coerceIn(0, (paragraphs.size - 1).coerceAtLeast(0))
    }

    /**
     * Loads a list of paragraphs directly.
     */
    fun setParagraphs(list: List<String>, startIndex: Int = 0) {
        synchronized(paragraphs) {
            paragraphs.clear()
            paragraphs.addAll(list.filter { it.isNotBlank() })
        }
        _totalParagraphs.value = paragraphs.size
        _currentParagraphIndex.value = startIndex.coerceIn(0, (paragraphs.size - 1).coerceAtLeast(0))
    }

    /**
     * Starts speaking from current paragraph or specified startIndex.
     */
    fun play(startIndex: Int? = null) {
        if (!isEngineReady) {
            pendingAutoPlay = true
            return
        }

        if (paragraphs.isEmpty()) {
            return
        }

        if (startIndex != null) {
            _currentParagraphIndex.value = startIndex.coerceIn(0, paragraphs.size - 1)
        }

        requestAudioFocus()
        startForegroundWithNotification()
        speakParagraph(_currentParagraphIndex.value)
    }

    /**
     * Pauses speech playback while preserving current position.
     */
    fun pause() {
        textToSpeech?.stop()
        updatePlaybackState(PlaybackState.PAUSED)
        updateForegroundNotification()
    }

    /**
     * Resumes speech playback from the current position.
     */
    fun resume() {
        if (_playbackState.value == PlaybackState.PAUSED) {
            requestAudioFocus()
            startForegroundWithNotification()
            speakParagraph(_currentParagraphIndex.value)
        } else if (_playbackState.value != PlaybackState.PLAYING) {
            play()
        }
    }

    /**
     * Stops speech playback, resets position to beginning and relinquishes resources.
     */
    fun stop() {
        textToSpeech?.stop()
        abandonAudioFocus()
        updatePlaybackState(PlaybackState.STOPPED)
        _currentParagraphIndex.value = 0
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /**
     * Skips to the next paragraph.
     */
    fun next() {
        val currentIdx = _currentParagraphIndex.value
        if (currentIdx < paragraphs.size - 1) {
            val nextIdx = currentIdx + 1
            _currentParagraphIndex.value = nextIdx
            if (_playbackState.value == PlaybackState.PLAYING) {
                speakParagraph(nextIdx)
            } else {
                updateForegroundNotification()
            }
        }
    }

    /**
     * Skips to the previous paragraph.
     */
    fun previous() {
        val currentIdx = _currentParagraphIndex.value
        if (currentIdx > 0) {
            val prevIdx = currentIdx - 1
            _currentParagraphIndex.value = prevIdx
            if (_playbackState.value == PlaybackState.PLAYING) {
                speakParagraph(prevIdx)
            } else {
                updateForegroundNotification()
            }
        }
    }

    /**
     * Seeks directly to a specific paragraph index.
     */
    fun seekToParagraph(index: Int) {
        if (index in 0 until paragraphs.size) {
            _currentParagraphIndex.value = index
            if (_playbackState.value == PlaybackState.PLAYING) {
                speakParagraph(index)
            } else {
                updateForegroundNotification()
            }
        }
    }

    // =========================================================================
    // Speech Rate & Audio Parameters
    // =========================================================================

    /**
     * Configures speech rate strictly between 0.5x and 5.0x.
     * Android TTS engines normally take 1.0 for normal speed.
     * Extreme values (> 3.0x or 4.0x) are gracefully clamped if the TTS engine returns error.
     */
    fun setSpeechRate(rate: Float): Boolean {
        val clampedRate = rate.coerceIn(MIN_SPEECH_RATE, MAX_SPEECH_RATE)
        _speechRate.value = clampedRate
        return applySpeechRate(clampedRate)
    }

    private fun applySpeechRate(rate: Float): Boolean {
        val tts = textToSpeech ?: return false
        return try {
            val res = tts.setSpeechRate(rate)
            if (res == TextToSpeech.ERROR && rate > 3.0f) {
                // If vendor engine does not support above 3.0x, clamp to 3.0x gracefully
                tts.setSpeechRate(3.0f)
                false
            } else {
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Configures speech pitch (0.5x to 2.0x, normal is 1.0x).
     */
    fun setPitch(pitch: Float) {
        val clampedPitch = pitch.coerceIn(0.5f, 2.0f)
        _pitch.value = clampedPitch
        applyPitch(clampedPitch)
    }

    private fun applyPitch(pitch: Float) {
        try {
            textToSpeech?.setPitch(pitch)
        } catch (_: Exception) { }
    }

    /**
     * Configures a specific Voice object.
     */
    fun setVoice(voice: Voice) {
        try {
            textToSpeech?.voice = voice
        } catch (_: Exception) { }
    }

    /**
     * Returns list of available voices.
     */
    fun getAvailableVoices(): List<Voice> {
        return try {
            textToSpeech?.voices?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun setLanguage(locale: Locale): Int {
        return textToSpeech?.setLanguage(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
    }

    fun setMetadata(title: String, subtitle: String = "") {
        _title.value = title
        _subtitle.value = subtitle
        updateForegroundNotification()
    }

    // =========================================================================
    // Internal Utterance & Playback Logic
    // =========================================================================

    private fun speakParagraph(index: Int) {
        val tts = textToSpeech ?: return
        if (index !in paragraphs.indices) return

        val textToSpeak = paragraphs[index]
        val utteranceId = "utterance_para_$index"

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        // QUEUE_FLUSH clears prior speech so the new paragraph starts immediately
        tts.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    private fun updatePlaybackState(state: PlaybackState) {
        _playbackState.value = state
        onPlaybackStateChanged?.invoke(state)
    }

    // =========================================================================
    // Audio Focus Management
    // =========================================================================

    private fun requestAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attributes)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener { focusChange ->
                    handleAudioFocusChange(focusChange)
                }
                .build()

            audioFocusRequest = request
            manager.requestAudioFocus(request)
        } else {
            @Suppress("DEPRECATION")
            manager.requestAudioFocus(
                { focusChange -> handleAudioFocusChange(focusChange) },
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
    }

    private fun abandonAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { manager.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            manager.abandonAudioFocus(null)
        }
    }

    private fun handleAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (_playbackState.value == PlaybackState.PLAYING) {
                    pause()
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                if (_playbackState.value == PlaybackState.PAUSED) {
                    resume()
                }
            }
        }
    }

    // =========================================================================
    // Foreground Notification & Media Controls
    // =========================================================================

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Text to Speech Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controls and status for text-to-speech reading"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val isPlaying = _playbackState.value == PlaybackState.PLAYING

        val playPauseAction = if (isPlaying) {
            NotificationCompat.Action(
                android.R.drawable.ic_media_pause,
                "Pause",
                PendingIntent.getService(
                    this,
                    101,
                    Intent(this, TextToSpeechService::class.java).apply { action = ACTION_PAUSE },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
        } else {
            NotificationCompat.Action(
                android.R.drawable.ic_media_play,
                "Play",
                PendingIntent.getService(
                    this,
                    101,
                    Intent(this, TextToSpeechService::class.java).apply { action = ACTION_PLAY },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
        }

        val prevAction = NotificationCompat.Action(
            android.R.drawable.ic_media_previous,
            "Previous",
            PendingIntent.getService(
                this,
                102,
                Intent(this, TextToSpeechService::class.java).apply { action = ACTION_PREVIOUS },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )

        val nextAction = NotificationCompat.Action(
            android.R.drawable.ic_media_next,
            "Next",
            PendingIntent.getService(
                this,
                103,
                Intent(this, TextToSpeechService::class.java).apply { action = ACTION_NEXT },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )

        val stopAction = NotificationCompat.Action(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Stop",
            PendingIntent.getService(
                this,
                104,
                Intent(this, TextToSpeechService::class.java).apply { action = ACTION_STOP },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )

        val paraDisplay = if (paragraphs.isNotEmpty()) {
            "Paragraph ${_currentParagraphIndex.value + 1} of ${paragraphs.size} • ${String.format(Locale.US, "%.2f", _speechRate.value)}x"
        } else {
            "Ready • ${String.format(Locale.US, "%.2f", _speechRate.value)}x"
        }

        val sub = _subtitle.value
        val displaySubtitle = if (sub.isNotBlank()) "$sub • $paraDisplay" else paraDisplay

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(_title.value)
            .setContentText(displaySubtitle)
            .setContentIntent(contentPendingIntent)
            .setOngoing(isPlaying)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(prevAction)
            .addAction(playPauseAction)
            .addAction(nextAction)
            .addAction(stopAction)
            .setStyle(NotificationCompat.BigTextStyle().bigText(displaySubtitle))
            .build()
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateForegroundNotification() {
        if (_playbackState.value == PlaybackState.PLAYING || _playbackState.value == PlaybackState.PAUSED) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(NOTIFICATION_ID, buildNotification())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        abandonAudioFocus()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        isEngineReady = false
        updatePlaybackState(PlaybackState.IDLE)
    }

    companion object {
        const val CHANNEL_ID = "tts_playback_channel"
        const val NOTIFICATION_ID = 2001

        const val MIN_SPEECH_RATE = 0.5f
        const val MAX_SPEECH_RATE = 5.0f

        const val ACTION_PLAY = "com.example.tts.action.PLAY"
        const val ACTION_PAUSE = "com.example.tts.action.PAUSE"
        const val ACTION_RESUME = "com.example.tts.action.RESUME"
        const val ACTION_STOP = "com.example.tts.action.STOP"
        const val ACTION_NEXT = "com.example.tts.action.NEXT"
        const val ACTION_PREVIOUS = "com.example.tts.action.PREVIOUS"
        const val ACTION_SET_RATE = "com.example.tts.action.SET_RATE"

        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_SUBTITLE = "extra_subtitle"
        const val EXTRA_SPEECH_RATE = "extra_speech_rate"

        /**
         * Helper function to build an intent to play text with configurable speech rate.
         */
        fun buildPlayIntent(
            context: Context,
            text: String,
            title: String = "Text to Speech",
            subtitle: String = "",
            speechRate: Float = 1.0f
        ): Intent {
            return Intent(context, TextToSpeechService::class.java).apply {
                action = ACTION_PLAY
                putExtra(EXTRA_TEXT, text)
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_SUBTITLE, subtitle)
                putExtra(EXTRA_SPEECH_RATE, speechRate.coerceIn(MIN_SPEECH_RATE, MAX_SPEECH_RATE))
            }
        }

        /**
         * Helper function to build a stop intent.
         */
        fun buildStopIntent(context: Context): Intent {
            return Intent(context, TextToSpeechService::class.java).apply {
                action = ACTION_STOP
            }
        }
    }
}
