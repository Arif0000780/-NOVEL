package com.example.tts

import android.content.Context
import android.content.Intent
import android.os.Build
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TtsPlaybackManager private constructor(private val context: Context) {

    private var engine: HindiTtsEngine? = null

    val isPlaying: StateFlow<Boolean> get() = engine?.isPlaying ?: _dummyFalse
    val isPaused: StateFlow<Boolean> get() = engine?.isPaused ?: _dummyFalse
    val currentParagraph: StateFlow<Int> get() = engine?.currentParagraph ?: _dummyZero
    val totalParagraphs: StateFlow<Int> get() = engine?.totalParagraphs ?: _dummyZero
    val statusMessage: StateFlow<String> get() = engine?.statusMessage ?: _dummyEmpty

    private val _novelTitle = MutableStateFlow("")
    val novelTitle: StateFlow<String> = _novelTitle.asStateFlow()

    private val _chapterTitle = MutableStateFlow("")
    val chapterTitle: StateFlow<String> = _chapterTitle.asStateFlow()

    private val _chapterId = MutableStateFlow<Long?>(null)
    val chapterId: StateFlow<Long?> = _chapterId.asStateFlow()

    private val _speed = MutableStateFlow(1.0f)
    val speed: StateFlow<Float> = _speed.asStateFlow()

    private val _pitch = MutableStateFlow(1.0f)
    val pitch: StateFlow<Float> = _pitch.asStateFlow()

    private val _dummyFalse = MutableStateFlow(false)
    private val _dummyZero = MutableStateFlow(0)
    private val _dummyEmpty = MutableStateFlow("")

    var onAutoNextChapterRequested: (() -> Unit)? = null

    init {
        initEngine()
    }

    private fun initEngine() {
        if (engine == null) {
            engine = HindiTtsEngine(context) { success ->
                if (success) {
                    engine?.setSpeed(_speed.value)
                    engine?.setPitch(_pitch.value)
                }
            }
            engine?.onChapterFinished = {
                onAutoNextChapterRequested?.invoke()
            }
        }
    }

    fun prepareChapter(
        novelTitle: String,
        chapterTitle: String,
        chapterId: Long,
        text: String,
        startParagraph: Int = 0
    ) {
        _novelTitle.value = novelTitle
        _chapterTitle.value = chapterTitle
        _chapterId.value = chapterId
        initEngine()
        engine?.loadContent(text, startParagraph)
    }

    fun play() {
        initEngine()
        engine?.play()
        startForegroundService()
    }

    fun pause() {
        engine?.pause()
    }

    fun resume() {
        engine?.resume()
        startForegroundService()
    }

    fun stop() {
        engine?.stop()
        stopForegroundService()
    }

    fun nextParagraph() {
        engine?.nextParagraph()
    }

    fun prevParagraph() {
        engine?.prevParagraph()
    }

    fun seekToParagraph(index: Int) {
        engine?.seekToParagraph(index)
    }

    fun setSpeed(speed: Float) {
        _speed.value = speed
        engine?.setSpeed(speed)
    }

    fun setPitch(pitch: Float) {
        _pitch.value = pitch
        engine?.setPitch(pitch)
    }

    fun getInstalledVoices(): List<Voice> {
        return engine?.getInstalledHindiVoices() ?: emptyList()
    }

    fun setVoice(voiceName: String) {
        engine?.setVoiceByName(voiceName)
    }

    private fun startForegroundService() {
        try {
            val intent = Intent(context, TtsPlaybackService::class.java).apply {
                action = TtsPlaybackService.ACTION_START
                putExtra(TtsPlaybackService.EXTRA_NOVEL_TITLE, _novelTitle.value)
                putExtra(TtsPlaybackService.EXTRA_CHAPTER_TITLE, _chapterTitle.value)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            // Ignored if background start restrictions prevent service start
        }
    }

    private fun stopForegroundService() {
        try {
            val intent = Intent(context, TtsPlaybackService::class.java)
            context.stopService(intent)
        } catch (e: Exception) {
            // Ignored
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: TtsPlaybackManager? = null

        fun getInstance(context: Context): TtsPlaybackManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TtsPlaybackManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
