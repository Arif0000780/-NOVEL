package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.translation.LanguageOption
import com.example.translation.NormalTranslationEngine
import com.example.translation.SupportedLanguages
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NormalTranslatorScreen(
    onNavigateBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // State for languages: Default [Auto Detect ▼]  →  [Hindi ▼]
    var sourceLang by remember {
        mutableStateOf(SupportedLanguages.SOURCE_LANGUAGES.first { it.code == "auto" })
    }
    var targetLang by remember {
        mutableStateOf(SupportedLanguages.TARGET_LANGUAGES.first { it.code == "hi" })
    }

    // Dialog state for selecting language
    var isSelectingSource by remember { mutableStateOf(false) }
    var isSelectingTarget by remember { mutableStateOf(false) }

    // Input & Output states
    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }
    var translationProgressText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // TextToSpeech State
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var isSpeaking by remember { mutableStateOf(false) }

    // Initialize TTS
    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status ->
            // Engine initialized
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeaking = true
            }

            override fun onDone(utteranceId: String?) {
                isSpeaking = false
            }

            override fun onError(utteranceId: String?) {
                isSpeaking = false
            }
        })
        tts = engine

        onDispose {
            try {
                engine.stop()
                engine.shutdown()
            } catch (_: Exception) {}
        }
    }

    fun speakText(text: String, langOption: LanguageOption) {
        val engine = tts ?: return
        if (isSpeaking) {
            engine.stop()
            isSpeaking = false
            return
        }
        if (text.isBlank()) return

        try {
            val locale = when (langOption.code.lowercase()) {
                "hi" -> Locale("hi", "IN")
                "en" -> Locale.ENGLISH
                "ur" -> Locale("ur", "PK")
                "ar" -> Locale("ar")
                "bn" -> Locale("bn", "IN")
                "ta" -> Locale("ta", "IN")
                "te" -> Locale("te", "IN")
                "mr" -> Locale("mr", "IN")
                "gu" -> Locale("gu", "IN")
                "pa" -> Locale("pa", "IN")
                "fr" -> Locale.FRENCH
                "de" -> Locale.GERMAN
                "es" -> Locale("es", "ES")
                "zh-cn", "zh" -> Locale.CHINESE
                "ja" -> Locale.JAPANESE
                "ko" -> Locale.KOREAN
                "ru" -> Locale("ru", "RU")
                "pt" -> Locale("pt", "BR")
                "it" -> Locale.ITALIAN
                else -> Locale.forLanguageTag(langOption.ttsLanguageTag)
            }

            engine.language = locale
            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "normal_translator_speech")
            val toSpeak = if (text.length > 3800) text.substring(0, 3800) else text
            engine.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, params, "normal_translator_speech")
            isSpeaking = true
        } catch (e: Exception) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("TTS Error: ${e.message}")
            }
        }
    }

    val scrollState = rememberScrollState()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.Translate,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Normal Translator",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Full-Text & Paragraph Translation",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (onNavigateBack != null) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (inputText.isNotEmpty() || translatedText.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                inputText = ""
                                translatedText = ""
                                errorMessage = null
                                if (isSpeaking) {
                                    tts?.stop()
                                    isSpeaking = false
                                }
                            },
                            modifier = Modifier.testTag("translator_header_clear_btn")
                        ) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear All")
                        }
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // =========================================================================
            // 1. LANGUAGE SELECTOR BAR: [Auto Detect ▼]  ⇄  [Hindi ▼]
            // =========================================================================
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("normal_translator_lang_bar"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Source Language Dropdown Selector: [Auto Detect ▼]
                    LanguageSelectorDropdown(
                        label = "From",
                        languageName = sourceLang.name,
                        nativeName = sourceLang.nativeName,
                        isAuto = sourceLang.isAuto,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("source_language_selector"),
                        onClick = { isSelectingSource = true }
                    )

                    // Swap Languages Button (with Auto Detect safety)
                    val canSwap = !sourceLang.isAuto
                    IconButton(
                        onClick = {
                            if (sourceLang.isAuto) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Cannot swap when Source is Auto Detect. Please select a specific source language.")
                                }
                            } else {
                                val currentSource = sourceLang
                                val currentTarget = targetLang
                                val newSource = SupportedLanguages.SOURCE_LANGUAGES.firstOrNull { it.code == currentTarget.code }
                                    ?: currentTarget
                                val newTarget = SupportedLanguages.TARGET_LANGUAGES.firstOrNull { it.code == currentSource.code }
                                    ?: currentSource

                                sourceLang = newSource
                                targetLang = newTarget

                                // Also swap text content if present
                                if (translatedText.isNotBlank()) {
                                    val tempInput = inputText
                                    inputText = translatedText
                                    translatedText = tempInput
                                }
                            }
                        },
                        enabled = !isTranslating,
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .testTag("swap_languages_button")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(
                                    if (canSwap) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.SwapHoriz,
                                contentDescription = "Swap Languages",
                                tint = if (canSwap) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                            )
                        }
                    }

                    // Target Language Dropdown Selector: [Hindi ▼]
                    LanguageSelectorDropdown(
                        label = "To",
                        languageName = targetLang.name,
                        nativeName = targetLang.nativeName,
                        isAuto = false,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("target_language_selector"),
                        onClick = { isSelectingTarget = true }
                    )
                }
            }

            // =========================================================================
            // 2. LARGE MULTILINE INPUT TEXT BOX: "Enter or paste text"
            // =========================================================================
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("normal_translator_input_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    MaterialTheme.colorScheme.outlineVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Original Text (${sourceLang.name})",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (inputText.isNotEmpty()) {
                                Text(
                                    text = "${inputText.length} chars",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = {
                                        inputText = ""
                                        errorMessage = null
                                    },
                                    modifier = Modifier
                                        .size(28.dp)
                                        .testTag("input_clear_btn")
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                }
                            } else {
                                FilledTonalButton(
                                    onClick = {
                                        val clip = clipboardManager.getText()?.text
                                        if (!clip.isNullOrBlank()) {
                                            inputText = clip
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar("Pasted from clipboard")
                                            }
                                        } else {
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar("Clipboard is empty")
                                            }
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .height(30.dp)
                                        .testTag("input_paste_btn"),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Filled.ContentPaste, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Paste", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Multiline Input Text Box with placeholder "Enter or paste text"
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = {
                            inputText = it
                            if (errorMessage != null) errorMessage = null
                        },
                        placeholder = {
                            Text(
                                "Enter or paste text (multiple sentences and paragraphs supported)",
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                            )
                        },
                        minLines = 5,
                        maxLines = 14,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("normal_translator_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                        )
                    )
                }
            }

            // =========================================================================
            // 3. VISIBLE TRANSLATE BUTTON & LOADING STATE
            // =========================================================================
            Button(
                onClick = {
                    val textToTranslate = inputText.trim()
                    if (textToTranslate.isEmpty()) {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Please enter or paste text to translate")
                        }
                        return@Button
                    }

                    isTranslating = true
                    errorMessage = null
                    translationProgressText = "Translating complete text..."

                    coroutineScope.launch {
                        val result = NormalTranslationEngine.translateCompleteText(
                            text = textToTranslate,
                            sourceLang = sourceLang.code,
                            targetLang = targetLang.code,
                            onProgress = { cur, tot ->
                                translationProgressText = "Translating paragraph $cur of $tot..."
                            }
                        )

                        isTranslating = false
                        result.onSuccess { output ->
                            translatedText = output
                            if (output.isNotBlank()) {
                                snackbarHostState.showSnackbar("Translation complete!")
                            }
                        }.onFailure { err ->
                            // Show clear error message and KEEP the original text
                            errorMessage = err.localizedMessage ?: "Translation failed. Please check internet connection."
                            snackbarHostState.showSnackbar(errorMessage ?: "Translation failed")
                        }
                    }
                },
                enabled = !isTranslating && inputText.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("normal_translator_translate_btn"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    disabledContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
            ) {
                if (isTranslating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Translating...",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Icon(
                        Icons.Filled.Translate,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TRANSLATE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // =========================================================================
            // 4. ERROR MESSAGE DISPLAY (Keeps original text intact)
            // =========================================================================
            AnimatedVisibility(visible = errorMessage != null) {
                errorMessage?.let { error ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("translator_error_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.ErrorOutline,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Translation Failed",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = error,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            IconButton(onClick = { errorMessage = null }) {
                                Icon(Icons.Filled.Close, contentDescription = "Dismiss", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 5. TRANSLATED OUTPUT CARD (Display complete result, all paragraphs)
            // =========================================================================
            if (translatedText.isNotBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("translation_output_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.5.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                                Text(
                                    text = "Translation (${targetLang.name})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = "${translatedText.length} chars",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))

                        // Complete Translated Result Display (Preserving paragraphs and line breaks)
                        SelectionContainer {
                            Text(
                                text = translatedText,
                                style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 26.sp),
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("translated_result_text")
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))

                        // Action Buttons: Copy, Speak, Clear
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Copy Button
                            OutlinedButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(translatedText))
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Translated text copied to clipboard!")
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("copy_translated_button")
                            ) {
                                Icon(
                                    Icons.Filled.ContentCopy,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Copy")
                            }

                            // Speak Button
                            FilledTonalButton(
                                onClick = {
                                    speakText(translatedText, targetLang)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (isSpeaking) MaterialTheme.colorScheme.errorContainer
                                    else MaterialTheme.colorScheme.secondaryContainer
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("speak_translated_button")
                            ) {
                                Icon(
                                    if (isSpeaking) Icons.Filled.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (isSpeaking) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    if (isSpeaking) "Stop" else "Speak",
                                    color = if (isSpeaking) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }

                            // Clear Output Button
                            OutlinedButton(
                                onClick = {
                                    if (isSpeaking) {
                                        tts?.stop()
                                        isSpeaking = false
                                    }
                                    translatedText = ""
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("clear_translated_button")
                            ) {
                                Icon(
                                    Icons.Filled.Clear,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // =========================================================================
    // SOURCE LANGUAGE SELECTION DIALOG
    // =========================================================================
    if (isSelectingSource) {
        LanguageSelectionDialog(
            title = "Select Source Language",
            languages = SupportedLanguages.SOURCE_LANGUAGES,
            selectedCode = sourceLang.code,
            onSelect = { selected ->
                sourceLang = selected
                isSelectingSource = false
            },
            onDismiss = { isSelectingSource = false }
        )
    }

    // =========================================================================
    // TARGET LANGUAGE SELECTION DIALOG
    // =========================================================================
    if (isSelectingTarget) {
        LanguageSelectionDialog(
            title = "Select Target Language",
            languages = SupportedLanguages.TARGET_LANGUAGES,
            selectedCode = targetLang.code,
            onSelect = { selected ->
                targetLang = selected
                isSelectingTarget = false
            },
            onDismiss = { isSelectingTarget = false }
        )
    }
}

/**
 * Clickable Dropdown Selector displaying [Language Name ▼]
 */
@Composable
private fun LanguageSelectorDropdown(
    label: String,
    languageName: String,
    nativeName: String,
    isAuto: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f, fill = false)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = languageName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!isAuto && nativeName.isNotBlank() && nativeName != languageName) {
                    Text(
                        text = nativeName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Icon(
                imageVector = Icons.Filled.ArrowDropDown,
                contentDescription = "Select $label Language",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

/**
 * Scrollable Language List Dialog with Search Filter
 */
@Composable
private fun LanguageSelectionDialog(
    title: String,
    languages: List<LanguageOption>,
    selectedCode: String,
    onSelect: (LanguageOption) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredLanguages = remember(searchQuery, languages) {
        if (searchQuery.isBlank()) {
            languages
        } else {
            languages.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.nativeName.contains(searchQuery, ignoreCase = true) ||
                        it.code.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .testTag("language_selection_dialog"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search language...") },
                    leadingIcon = {
                        Icon(Icons.Filled.Search, contentDescription = null)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("language_search_box")
                )

                Spacer(modifier = Modifier.height(12.dp))

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Scrollable Language List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(top = 8.dp)
                        .testTag("language_dialog_list"),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredLanguages, key = { it.code }) { lang ->
                        val isSelected = lang.code.equals(selectedCode, ignoreCase = true)
                        Surface(
                            onClick = { onSelect(lang) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("lang_item_${lang.code}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = lang.name,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (!lang.isAuto && lang.nativeName.isNotBlank() && lang.nativeName != lang.name) {
                                        Text(
                                            text = lang.nativeName,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                if (isSelected) {
                                    Icon(
                                        Icons.Filled.Check,
                                        contentDescription = "Selected",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
