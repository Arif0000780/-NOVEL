package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.translation.isPureHindi
import com.example.ui.theme.*
import com.example.ui.viewmodel.ReaderViewModel
import com.example.ui.viewmodel.TtsViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    chapterId: Long,
    readerViewModel: ReaderViewModel,
    ttsViewModel: TtsViewModel,
    onNavigateBack: () -> Unit,
    onOpenTtsPlayer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val uiState by readerViewModel.uiState.collectAsState()
    val settings by readerViewModel.settings.collectAsState()

    val ttsPlaying by ttsViewModel.isPlaying.collectAsState()
    val ttsActiveChapterId by ttsViewModel.activeChapterId.collectAsState()
    val ttsCurrentPara by ttsViewModel.currentParagraph.collectAsState()

    val listState = rememberLazyListState()
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showNextUrlDialog by remember { mutableStateOf(false) }
    var nextUrlInput by remember { mutableStateOf("") }

    LaunchedEffect(chapterId) {
        readerViewModel.loadChapter(chapterId)
    }

    // Scroll sync with TTS paragraph if same chapter is speaking
    LaunchedEffect(ttsCurrentPara, ttsActiveChapterId) {
        if (ttsActiveChapterId == chapterId && ttsCurrentPara >= 0) {
            listState.animateScrollToItem((ttsCurrentPara + 1).coerceAtLeast(0))
        }
    }

    // Determine current theme colors
    val (bgColor, textColor, surfaceColor) = when (settings.readerTheme.lowercase()) {
        "sepia" -> Triple(SepiaBackground, SepiaText, SepiaSurface)
        "light" -> Triple(LightCanvas, LightText, LightSurface)
        else -> Triple(IndigoCanvas, Color(0xFFE2DCED), SurfaceCardDark)
    }

    val chapter = uiState.chapter
    val novel = uiState.novel
    val translation = uiState.translation
    val isTranslatedPureHindi = translation != null && isPureHindi(translation.translatedContent)

    val displayedTitle = if (uiState.showHindi && isTranslatedPureHindi) {
        translation!!.translatedTitle
    } else {
        chapter?.title ?: ""
    }

    val displayedContent = if (uiState.showHindi && isTranslatedPureHindi) {
        translation!!.translatedContent
    } else {
        chapter?.content ?: ""
    }

    val paragraphs = remember(displayedContent) {
        val list = displayedContent.split("\n\n").map { it.trim() }.filter { it.isNotBlank() }
        if (list.isEmpty() && displayedContent.isNotBlank()) listOf(displayedContent) else list
    }

    // Save reading progress on scroll
    LaunchedEffect(listState.firstVisibleItemIndex, paragraphs.size) {
        if (paragraphs.isNotEmpty()) {
            val currentIdx = (listState.firstVisibleItemIndex - 1).coerceIn(0, paragraphs.size - 1)
            val percent = (currentIdx.toFloat() / paragraphs.size.toFloat()).coerceIn(0f, 1f)
            readerViewModel.updateReadingPosition(currentIdx, percent)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = displayedTitle,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                        Text(
                            text = if (uiState.showHindi && isTranslatedPureHindi) "हिंदी अनुवाद" else "मूल भाषा (Original)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = textColor)
                    }
                },
                actions = {
                    // Language Switch Toggle
                    IconButton(
                        onClick = {
                            if (!isTranslatedPureHindi && !uiState.showHindi) {
                                readerViewModel.translateChapter()
                            } else {
                                readerViewModel.toggleLanguage()
                            }
                        },
                        modifier = Modifier.testTag("reader_toggle_language")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Translate,
                            contentDescription = "Toggle Language",
                            tint = if (uiState.showHindi && isTranslatedPureHindi) MaterialTheme.colorScheme.primary else textColor
                        )
                    }

                    // Bookmark Button
                    IconButton(
                        onClick = { readerViewModel.bookmarkCurrentParagraph() },
                        modifier = Modifier.testTag("reader_bookmark_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (uiState.isBookmarked) MaterialTheme.colorScheme.secondary else textColor
                        )
                    }

                    // Reader Settings Button
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("reader_settings_button")
                    ) {
                        Icon(Icons.Filled.Tune, contentDescription = "Reading Settings", tint = textColor)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bgColor)
            )
        },
        bottomBar = {
            Surface(
                color = surfaceColor,
                tonalElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Previous Chapter
                    IconButton(
                        onClick = {
                            readerViewModel.navigateToPrevChapter { newId ->
                                coroutineScope.launch { listState.scrollToItem(0) }
                            }
                        },
                        modifier = Modifier.testTag("reader_prev_chapter_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Chapter", tint = textColor)
                    }

                    // Quick Hindi TTS Play Button
                    Button(
                        onClick = {
                            if (chapter != null && novel != null) {
                                val currentTrans = translation?.translatedContent
                                if (currentTrans != null && isPureHindi(currentTrans)) {
                                    ttsViewModel.startPlayback(
                                        novelTitle = novel.title,
                                        chapterTitle = translation.translatedTitle,
                                        chapterId = chapter.id,
                                        hindiText = currentTrans,
                                        startParagraph = uiState.currentParagraphIndex
                                    )
                                    onOpenTtsPlayer()
                                } else {
                                    // Translate full chapter to pure Hindi first, then play pure Hindi TTS
                                    readerViewModel.translateChapter(chapter) { fullyTranslatedHindi ->
                                        val pureTitle = readerViewModel.uiState.value.translation?.translatedTitle ?: chapter.title
                                        ttsViewModel.startPlayback(
                                            novelTitle = novel.title,
                                            chapterTitle = pureTitle,
                                            chapterId = chapter.id,
                                            hindiText = fullyTranslatedHindi,
                                            startParagraph = 0
                                        )
                                        onOpenTtsPlayer()
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("reader_tts_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (ttsPlaying && ttsActiveChapterId == chapterId) "Playing Audio" else "Hindi TTS")
                    }

                    // Next Chapter
                    IconButton(
                        onClick = {
                            readerViewModel.navigateToNextChapter(
                                onSuccess = { newId ->
                                    coroutineScope.launch { listState.scrollToItem(0) }
                                },
                                onNextUrlNeeded = { detectedUrl ->
                                    if (!detectedUrl.isNullOrBlank()) {
                                        readerViewModel.fetchAndImportNextChapterFromUrl(detectedUrl) { newId ->
                                            coroutineScope.launch { listState.scrollToItem(0) }
                                        }
                                    } else {
                                        showNextUrlDialog = true
                                    }
                                }
                            )
                        },
                        modifier = Modifier.testTag("reader_next_chapter_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Chapter", tint = textColor)
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgColor)
                .padding(innerPadding)
        ) {
            if (chapter == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Header Card
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = novel?.title ?: "",
                                style = MaterialTheme.typography.labelLarge,
                                color = textColor.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = displayedTitle,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                color = textColor
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Translation Action Bar
                            if (uiState.isTranslating) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Translating chapter to Hindi...", style = MaterialTheme.typography.bodySmall, color = textColor)
                                }
                            } else if (!isTranslatedPureHindi) {
                                FilledTonalButton(
                                    onClick = { readerViewModel.translateChapter() },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("translate_chapter_button")
                                ) {
                                    Icon(Icons.Filled.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Translate to Hindi Now")
                                }
                            }

                            if (uiState.translationError != null) {
                                Text(
                                    text = uiState.translationError ?: "",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.clickable { readerViewModel.translateChapter() }
                                )
                            }
                        }
                    }

                    // Chapter Paragraphs
                    itemsIndexed(paragraphs) { index, paragraph ->
                        val isCurrentTtsPara = (ttsActiveChapterId == chapterId && ttsPlaying && ttsCurrentPara == index)
                        val paraBg = if (isCurrentTtsPara) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        } else {
                            Color.Transparent
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = settings.paragraphSpacing.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(paraBg)
                                .clickable {
                                    // Tap paragraph to seek TTS speech
                                    if (ttsActiveChapterId == chapterId) {
                                        ttsViewModel.seekToParagraph(index)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = paragraph,
                                fontSize = settings.fontSize.sp,
                                lineHeight = (settings.fontSize * settings.lineSpacing).sp,
                                color = textColor,
                                fontFamily = when (settings.fontFamily.lowercase()) {
                                    "serif" -> FontFamily.Serif
                                    "monospace" -> FontFamily.Monospace
                                    else -> FontFamily.Default
                                }
                            )
                        }
                    }

                    // Smart Next Chapter Section at bottom of page
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            HorizontalDivider(color = textColor.copy(alpha = 0.2f))
                            Text(
                                text = "End of Chapter ${chapter.chapterNumber}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = textColor
                            )

                            Button(
                                onClick = {
                                    readerViewModel.navigateToNextChapter(
                                        onSuccess = { coroutineScope.launch { listState.scrollToItem(0) } },
                                        onNextUrlNeeded = { detectedUrl ->
                                            if (!detectedUrl.isNullOrBlank()) {
                                                readerViewModel.fetchAndImportNextChapterFromUrl(detectedUrl) {
                                                    coroutineScope.launch { listState.scrollToItem(0) }
                                                }
                                            } else {
                                                showNextUrlDialog = true
                                            }
                                        }
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("reader_bottom_next_chapter")
                            ) {
                                Text("Proceed to Next Chapter")
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                            }
                        }
                    }
                }
            }

            // Snackbar notification
            if (uiState.messageSnackbar != null) {
                Snackbar(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    action = {
                        TextButton(onClick = { readerViewModel.dismissSnackbar() }) {
                            Text("OK")
                        }
                    }
                ) {
                    Text(uiState.messageSnackbar ?: "")
                }
            }
        }
    }

    // Reading Settings Bottom Sheet
    if (showSettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSettingsSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text(
                    text = "Reader Settings",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // Font Size
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Font Size: ${settings.fontSize}sp", fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = { readerViewModel.decreaseFontSize() }) {
                            Text("A-")
                        }
                        FilledTonalButton(onClick = { readerViewModel.increaseFontSize() }) {
                            Text("A+")
                        }
                    }
                }

                // Theme selection
                Column {
                    Text("Background Theme", fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Dark", "Light", "Sepia").forEach { themeName ->
                            val selected = settings.readerTheme.equals(themeName, ignoreCase = true)
                            FilterChip(
                                selected = selected,
                                onClick = { readerViewModel.setReaderTheme(themeName) },
                                label = { Text(themeName) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Line Spacing
                Column {
                    Text("Line Spacing: ${settings.lineSpacing}x", fontWeight = FontWeight.Medium)
                    Slider(
                        value = settings.lineSpacing,
                        onValueChange = { readerViewModel.setLineSpacing(it) },
                        valueRange = 1.2f..2.2f,
                        steps = 4
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Next Chapter URL Prompt Dialog
    if (showNextUrlDialog) {
        AlertDialog(
            onDismissRequest = { showNextUrlDialog = false },
            title = { Text("Enter Next Chapter URL") },
            text = {
                Column {
                    Text("No automatic next link was detected for this chapter. Please enter the URL of the next chapter:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nextUrlInput,
                        onValueChange = { nextUrlInput = it },
                        placeholder = { Text("https://example.com/novel/chapter-next") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nextUrlInput.isNotBlank()) {
                            readerViewModel.fetchAndImportNextChapterFromUrl(nextUrlInput.trim()) { newId ->
                                coroutineScope.launch { listState.scrollToItem(0) }
                            }
                        }
                        showNextUrlDialog = false
                    }
                ) {
                    Text("Import & Open")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNextUrlDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
