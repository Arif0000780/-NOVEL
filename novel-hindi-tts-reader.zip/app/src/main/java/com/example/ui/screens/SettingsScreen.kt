package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settingsViewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val settings by settingsViewModel.settings.collectAsState()
    val statusMessage by settingsViewModel.statusMessage.collectAsState()

    var showClearConfirmDialog by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Status message
            if (statusMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = statusMessage ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        IconButton(onClick = { settingsViewModel.dismissStatus() }) {
                            Icon(Icons.Filled.Close, contentDescription = "Dismiss")
                        }
                    }
                }
            }

            // Reading Settings Section
            SettingsSectionHeader(title = "Reading Settings", icon = Icons.Filled.FormatSize)

            Card(shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Default Font Size", fontWeight = FontWeight.Medium)
                        Text("${settings.fontSize} sp", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.fontSize.toFloat(),
                        onValueChange = { settingsViewModel.updateFontSize(it.toInt()) },
                        valueRange = 14f..30f,
                        steps = 7
                    )

                    HorizontalDivider()

                    Text("Default Reader Theme", fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Dark", "Light", "Sepia").forEach { themeName ->
                            FilterChip(
                                selected = settings.readerTheme.equals(themeName, ignoreCase = true),
                                onClick = { settingsViewModel.updateReaderTheme(themeName) },
                                label = { Text(themeName) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Translation Settings Section
            SettingsSectionHeader(title = "Translation Settings", icon = Icons.Filled.Translate)

            Card(shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Translation Style", fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("NATURAL" to "Natural", "SIMPLE" to "Simple", "LITERARY" to "Literary").forEach { (styleKey, label) ->
                            FilterChip(
                                selected = settings.translationStyle == styleKey,
                                onClick = { settingsViewModel.updateTranslationStyle(styleKey) },
                                label = { Text(label) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Translate", fontWeight = FontWeight.Medium)
                            Text("Translate chapters automatically upon opening", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.autoTranslate,
                            onCheckedChange = { settingsViewModel.toggleAutoTranslate(it) }
                        )
                    }
                }
            }

            // TTS Speech Settings Section
            SettingsSectionHeader(title = "Hindi TTS & Audio Settings", icon = Icons.Filled.VolumeUp)

            Card(shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Default Speech Speed", fontWeight = FontWeight.Medium)
                        Text("${String.format("%.2f", settings.speechSpeed)}x", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.speechSpeed,
                        onValueChange = { settingsViewModel.updateSpeechSpeed(it) },
                        valueRange = 0.5f..5.0f,
                        steps = 17
                    )

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Play", fontWeight = FontWeight.Medium)
                            Text("Start audio automatically after chapter loads", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.autoPlay,
                            onCheckedChange = { settingsViewModel.toggleAutoPlay(it) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Next Paragraph", fontWeight = FontWeight.Medium)
                            Text("Seamless continuous narration without manual clicks", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.autoNextParagraph,
                            onCheckedChange = { settingsViewModel.toggleAutoNextParagraph(it) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Next Chapter", fontWeight = FontWeight.Medium)
                            Text("Automatically advance, extract, translate, and speak next chapter", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.autoNextChapter,
                            onCheckedChange = { settingsViewModel.toggleAutoNextChapter(it) }
                        )
                    }
                }
            }

            // Storage & Maintenance Section
            SettingsSectionHeader(title = "Storage & Cache", icon = Icons.Filled.Storage)

            Card(shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { showClearConfirmDialog = "TRANSLATION" },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.CleaningServices, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Clear Translation Cache")
                    }

                    OutlinedButton(
                        onClick = { showClearConfirmDialog = "HISTORY" },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Clear Reading Data & Progress")
                    }
                }
            }

            // About & Legal Section
            SettingsSectionHeader(title = "About & Compliance", icon = Icons.Filled.Info)

            Card(shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Novel Hindi TTS Reader", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Version 1.0.0 • Production Build", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Content Responsibility Notice: This application is a personal reader tool that only processes publicly accessible content that users choose to import. It does not scrape, redistribute, or bypass security, login, or DRM protections.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Confirmation Dialog
    if (showClearConfirmDialog != null) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = null },
            title = { Text("Confirm Clear") },
            text = {
                Text(
                    if (showClearConfirmDialog == "TRANSLATION")
                        "Do you want to clear all cached Hindi translations? Chapters will re-translate when opened."
                    else
                        "Do you want to clear all reading progress and audio positions?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (showClearConfirmDialog == "TRANSLATION") {
                            settingsViewModel.clearTranslationCache()
                        } else {
                            settingsViewModel.clearReadingData()
                        }
                        showClearConfirmDialog = null
                    }
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 8.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}
