package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.TtsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TtsPlayerScreen(
    ttsViewModel: TtsViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPlaying by ttsViewModel.isPlaying.collectAsState()
    val isPaused by ttsViewModel.isPaused.collectAsState()
    val currentPara by ttsViewModel.currentParagraph.collectAsState()
    val totalParas by ttsViewModel.totalParagraphs.collectAsState()
    val statusMsg by ttsViewModel.statusMessage.collectAsState()
    val novelTitle by ttsViewModel.novelTitle.collectAsState()
    val chapterTitle by ttsViewModel.chapterTitle.collectAsState()
    val speed by ttsViewModel.speed.collectAsState()
    val pitch by ttsViewModel.pitch.collectAsState()

    val installedVoices = remember { ttsViewModel.getInstalledHindiVoices() }
    var showVoiceDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hindi TTS Player", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showVoiceDialog = true }) {
                        Icon(Icons.Filled.RecordVoiceOver, contentDescription = "Select Hindi Voice")
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Visual Artwork Banner
            Card(
                modifier = Modifier
                    .size(160.dp)
                    .clip(RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Filled.Headphones,
                        contentDescription = null,
                        modifier = Modifier.size(80.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Titles
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = novelTitle.ifEmpty { "Hindi Novel Audio" },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = chapterTitle.ifEmpty { "Chapter Audio" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Status message (e.g. rate clamped or voice info)
            if (statusMsg.isNotBlank()) {
                Text(
                    text = statusMsg,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    textAlign = TextAlign.Center
                )
            }

            // Paragraph Progress
            Column(modifier = Modifier.fillMaxWidth()) {
                val progress = if (totalParas > 0) (currentPara + 1).toFloat() / totalParas else 0f
                Slider(
                    value = progress,
                    onValueChange = { newProg ->
                        val targetPara = (newProg * totalParas).toInt().coerceIn(0, (totalParas - 1).coerceAtLeast(0))
                        ttsViewModel.seekToParagraph(targetPara)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Paragraph ${currentPara + 1}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Total $totalParas",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Primary Playback Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Prev Paragraph
                IconButton(
                    onClick = { ttsViewModel.prevParagraph() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("tts_prev_paragraph")
                ) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous Paragraph", modifier = Modifier.size(32.dp))
                }

                // Play / Pause / Resume
                FilledIconButton(
                    onClick = {
                        if (isPlaying) {
                            ttsViewModel.pause()
                        } else if (isPaused) {
                            ttsViewModel.resume()
                        } else {
                            ttsViewModel.play()
                        }
                    },
                    modifier = Modifier
                        .size(72.dp)
                        .testTag("tts_play_pause_button"),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(40.dp)
                    )
                }

                // Next Paragraph
                IconButton(
                    onClick = { ttsViewModel.nextParagraph() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("tts_next_paragraph")
                ) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Next Paragraph", modifier = Modifier.size(32.dp))
                }

                // Stop
                IconButton(
                    onClick = { ttsViewModel.stop() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("tts_stop_button")
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = "Stop", modifier = Modifier.size(32.dp))
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

            // Speech Speed: 0.5x to 5.0x
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Speech Speed",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${String.format("%.2f", speed)}x",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Slider(
                    value = speed,
                    onValueChange = { ttsViewModel.setSpeed(it) },
                    valueRange = 0.5f..5.0f,
                    steps = 17,
                    modifier = Modifier.fillMaxWidth()
                )

                // Quick Select Chips (0.5x to 5.0x)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ttsViewModel.speedOptions) { spdOpt ->
                        val isSelected = kotlin.math.abs(speed - spdOpt) < 0.05f
                        FilterChip(
                            selected = isSelected,
                            onClick = { ttsViewModel.setSpeed(spdOpt) },
                            label = { Text("${spdOpt}x", fontSize = 12.sp) }
                        )
                    }
                }
            }

            // Pitch Control (Low, Normal, High)
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pitch",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = when {
                            pitch < 0.9f -> "Low (${String.format("%.1f", pitch)})"
                            pitch > 1.2f -> "High (${String.format("%.1f", pitch)})"
                            else -> "Normal (1.0)"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Slider(
                    value = pitch,
                    onValueChange = { ttsViewModel.setPitch(it) },
                    valueRange = 0.6f..1.6f,
                    steps = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = kotlin.math.abs(pitch - 0.75f) < 0.1f,
                        onClick = { ttsViewModel.setPitch(0.75f) },
                        label = { Text("Low") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = kotlin.math.abs(pitch - 1.0f) < 0.1f,
                        onClick = { ttsViewModel.setPitch(1.0f) },
                        label = { Text("Normal") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = kotlin.math.abs(pitch - 1.35f) < 0.1f,
                        onClick = { ttsViewModel.setPitch(1.35f) },
                        label = { Text("High") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    // Voice Selection Dialog
    if (showVoiceDialog) {
        AlertDialog(
            onDismissRequest = { showVoiceDialog = false },
            title = { Text("Select Hindi TTS Voice") },
            text = {
                if (installedVoices.isEmpty()) {
                    Text("No dedicated Hindi voices listed. Using system default Hindi speech engine.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        installedVoices.forEach { voice ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp)),
                                onClick = {
                                    ttsViewModel.selectVoice(voice.name)
                                    showVoiceDialog = false
                                }
                            ) {
                                Text(
                                    text = voice.name,
                                    modifier = Modifier.padding(12.dp),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showVoiceDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}
