package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.viewmodel.NovelViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UrlImportScreen(
    novelViewModel: NovelViewModel,
    initialUrl: String = "",
    onNavigateBack: () -> Unit,
    onChapterImported: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val importState by novelViewModel.urlImportState.collectAsState()
    var urlText by remember { mutableStateOf(initialUrl.ifEmpty { importState.url }) }
    var showInAppBrowser by remember { mutableStateOf(false) }
    var browserCurrentUrl by remember { mutableStateOf("") }
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }

    LaunchedEffect(initialUrl) {
        if (initialUrl.isNotBlank()) {
            novelViewModel.setImportUrl(initialUrl)
            novelViewModel.fetchAndExtractFromUrl(initialUrl)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Import Chapter from URL") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(
                        onClick = { showInAppBrowser = !showInAppBrowser }
                    ) {
                        Icon(
                            if (showInAppBrowser) Icons.Filled.Description else Icons.Filled.Web,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showInAppBrowser) "Editor" else "In-App Browser")
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // URL Input bar
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = urlText,
                            onValueChange = {
                                urlText = it
                                novelViewModel.setImportUrl(it)
                            },
                            placeholder = { Text("Enter or paste HTTP/HTTPS chapter URL") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("import_url_field"),
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Filled.Link, contentDescription = null) },
                            trailingIcon = {
                                if (urlText.isNotEmpty()) {
                                    IconButton(onClick = { urlText = "" }) {
                                        Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                    }
                                }
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                novelViewModel.fetchAndExtractFromUrl(urlText)
                                if (showInAppBrowser) {
                                    webViewInstance?.loadUrl(urlText)
                                }
                            },
                            enabled = !importState.isLoading && urlText.isNotBlank(),
                            modifier = Modifier.testTag("import_fetch_button")
                        ) {
                            if (importState.isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                            } else {
                                Text("Extract")
                            }
                        }
                    }

                    Text(
                        text = "🔒 Respects copyright & terms. Only authorized public novel pages are processed.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }

            if (importState.errorMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = importState.errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            if (showInAppBrowser) {
                // In-App Browser View
                Box(modifier = Modifier.weight(1f)) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                @SuppressLint("SetJavaScriptEnabled")
                                settings.javaScriptEnabled = false // Security: do not execute unnecessary JS
                                settings.domStorageEnabled = false
                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        super.onPageFinished(view, url)
                                        if (url != null) {
                                            browserCurrentUrl = url
                                        }
                                    }
                                }
                                loadUrl(urlText.ifBlank { "https://example.com" })
                                webViewInstance = this
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    FloatingActionButton(
                        onClick = {
                            val current = browserCurrentUrl.ifEmpty { urlText }
                            novelViewModel.fetchAndExtractFromUrl(current)
                            showInAppBrowser = false
                        },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AutoFixHigh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Extract Page")
                        }
                    }
                }
            } else {
                // Extracted Content Preview & Editor Screen
                if (importState.extractedChapter != null) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Extracted Preview (Editable)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val nextLink = importState.extractedChapter?.nextChapterUrl
                            if (!nextLink.isNullOrBlank()) {
                                AssistChip(
                                    onClick = {},
                                    label = { Text("Next Link Detected") },
                                    leadingIcon = { Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = importState.editableNovelTitle,
                            onValueChange = { novelViewModel.updateEditableContent(importState.editableTitle, it, importState.editableContent) },
                            label = { Text("Novel Title") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = importState.editableTitle,
                            onValueChange = { novelViewModel.updateEditableContent(it, importState.editableNovelTitle, importState.editableContent) },
                            label = { Text("Chapter Title") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = importState.editableContent,
                            onValueChange = { novelViewModel.updateEditableContent(importState.editableTitle, importState.editableNovelTitle, it) },
                            label = { Text("Main Chapter Text") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 260.dp, max = 450.dp)
                        )

                        Button(
                            onClick = {
                                novelViewModel.saveImportedChapter { savedChapterId ->
                                    onChapterImported(savedChapterId)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp)
                                .testTag("save_imported_chapter_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.BookmarkAdded, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save & Open in Reader", fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Filled.CloudDownload,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Enter a publicly accessible novel or chapter URL above and tap 'Extract'.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
