package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SaffronPrimary = Color(0xFFE65100)
val SaffronLight = Color(0xFFFF8A50)
val SaffronDark = Color(0xFFAC1900)

val IndigoDark = Color(0xFF1E1B2E)
val IndigoCanvas = Color(0xFF12101C)
val SurfaceDark = Color(0xFF1A1829)
val SurfaceCardDark = Color(0xFF242036)

val AmberAccent = Color(0xFFFFB300)
val TealAccent = Color(0xFF00897B)

// Sepia Reader palette
val SepiaBackground = Color(0xFFF4ECD8)
val SepiaSurface = Color(0xFFEAE0C8)
val SepiaText = Color(0xFF4A3E31)
val SepiaSecondaryText = Color(0xFF7D6B57)

// Light Reader palette
val LightCanvas = Color(0xFFFAF7F2)
val LightSurface = Color(0xFFFFFFFF)
val LightText = Color(0xFF1E1B18)
val LightSecondaryText = Color(0xFF6B655E)
