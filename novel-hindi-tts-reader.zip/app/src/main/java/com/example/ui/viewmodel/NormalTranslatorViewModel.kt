package com.example.ui.viewmodel

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.translation.LanguageRegistry
import com.example.translation.SupportedLanguage
import com.example.translation.UniversalTranslator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class NormalTranslatorViewModel(
    private val universalTranslator: UniversalTranslator = UniversalTranslator()
) : ViewModel() {

    private val _sourceLanguage = MutableStateFlow<SupportedLanguage>(LanguageRegistry.AUTO_DETECT)
    val sourceLanguage: StateFlow<SupportedLanguage> = _sourceLanguage.asStateFlow()

    private val _targetLanguage = MutableStateFlow<SupportedLanguage>(LanguageRegistry.fromCode("hi"))
    val targetLanguage: StateFlow<SupportedLanguage> = _targetLanguage.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _translatedText = MutableStateFlow("")
    val translatedText: StateFlow<String> = _translatedText.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var textToSpeech: TextToSpeech? = null
    private var ttsInitialized = false

    fun setSourceLanguage(language: SupportedLanguage) {
        _sourceLanguage.value = language
    }

    fun setTargetLanguage(language: SupportedLanguage) {
        if (!language.isAutoDetect) {
            _targetLanguage.value = language
        }
    }

    fun swapLanguages() {
        val currentSource = _sourceLanguage.value
        val currentTarget = _targetLanguage.value

        // Do not allow swapping when Source Language is Auto Detect
        if (currentSource.isAutoDetect) {
            _snackbarMessage.value = "Cannot swap when Source is Auto Detect. Select a specific language first."
            return
        }

        _sourceLanguage.value = currentTarget
        _targetLanguage.value = currentSource

        // Also swap text if translated text is present
        if (_translatedText.value.isNotBlank()) {
            val oldInput = _inputText.value
            _inputText.value = _translatedText.value
            _translatedText.value = oldInput
        }
    }

    fun setInputText(text: String) {
        _inputText.value = text
        if (_errorMessage.value != null) {
            _errorMessage.value = null
        }
    }

    fun translate() {
        val textToTranslate = _inputText.value
        if (textToTranslate.isBlank()) {
            _translatedText.value = ""
            _errorMessage.value = "Please enter or paste text to translate"
            return
        }

        viewModelScope.launch {
            _isTranslating.value = true
            _errorMessage.value = null

            val result = universalTranslator.translateText(
                text = textToTranslate,
                sourceLangCode = _sourceLanguage.value.code,
                targetLangCode = _targetLanguage.value.code
            )

            result.onSuccess { translated ->
                _translatedText.value = translated
                _isTranslating.value = false
            }.onFailure { error ->
                _isTranslating.value = false
                _errorMessage.value = error.localizedMessage ?: "Translation failed. Please check internet connection."
            }
        }
    }

    fun clearAll() {
        _inputText.value = ""
        _translatedText.value = ""
        _errorMessage.value = null
        stopSpeak()
    }

    fun copyTranslation(clipboardManager: ClipboardManager) {
        val text = _translatedText.value
        if (text.isNotBlank()) {
            clipboardManager.setText(AnnotatedString(text))
            _snackbarMessage.value = "Translated text copied to clipboard"
        }
    }

    fun speakTranslation(context: Context) {
        val text = _translatedText.value
        if (text.isBlank()) return

        if (_isSpeaking.value) {
            stopSpeak()
            return
        }

        if (textToSpeech == null) {
            textToSpeech = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsInitialized = true
                    playSpeechInternal(text, _targetLanguage.value.code)
                } else {
                    _snackbarMessage.value = "TTS engine initialization failed"
                }
            }
        } else {
            playSpeechInternal(text, _targetLanguage.value.code)
        }
    }

    private fun playSpeechInternal(text: String, langCode: String) {
        val tts = textToSpeech ?: return
        try {
            val locale = getLocaleForCode(langCode)
            tts.language = locale

            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })

            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "normal_trans_tts")
            // Speak in chunks if very long for TTS
            val toSpeak = if (text.length > 3900) text.substring(0, 3900) else text
            tts.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, params, "normal_trans_tts")
            _isSpeaking.value = true
        } catch (e: Exception) {
            _isSpeaking.value = false
            _snackbarMessage.value = "Speech playback error: ${e.message}"
        }
    }

    fun stopSpeak() {
        textToSpeech?.stop()
        _isSpeaking.value = false
    }

    private fun getLocaleForCode(code: String): Locale {
        return when (code.lowercase()) {
            "hi" -> Locale("hi", "IN")
            "en" -> Locale.ENGLISH
            "ur" -> Locale("ur", "PK")
            "ar" -> Locale("ar")
            "bn" -> Locale("bn", "IN")
            "ta" -> Locale("ta", "IN")
            "te" -> Locale("te", "IN")
            "mr" -> Locale("mr", "IN")
            "gu" -> Locale("gu", "IN")
            "pa" -> Locale("pa", "IN")
            "fr" -> Locale.FRENCH
            "de" -> Locale.GERMAN
            "es" -> Locale("es", "ES")
            "zh-cn", "zh" -> Locale.CHINESE
            "ja" -> Locale.JAPANESE
            "ko" -> Locale.KOREAN
            "ru" -> Locale("ru", "RU")
            "pt" -> Locale("pt", "BR")
            "it" -> Locale.ITALIAN
            else -> Locale.forLanguageTag(code)
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }
}
