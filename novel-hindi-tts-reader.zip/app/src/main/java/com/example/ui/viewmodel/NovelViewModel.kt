package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.NovelEntity
import com.example.data.repository.NovelRepository
import com.example.parser.ExtractedChapter
import com.example.parser.ParserManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class NovelSortOrder {
    RECENT, TITLE, PROGRESS, FAVORITES
}

data class UrlImportUiState(
    val url: String = "",
    val isLoading: Boolean = false,
    val extractedChapter: ExtractedChapter? = null,
    val editableContent: String = "",
    val editableTitle: String = "",
    val editableNovelTitle: String = "",
    val errorMessage: String? = null,
    val isSavedSuccess: Boolean = false
)

class NovelViewModel(
    private val novelRepository: NovelRepository,
    private val parserManager: ParserManager
) : ViewModel() {

    val allNovels: StateFlow<List<NovelEntity>> = novelRepository.getAllNovels()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteNovels: StateFlow<List<NovelEntity>> = novelRepository.getFavoriteNovels()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentNovels: StateFlow<List<NovelEntity>> = novelRepository.getRecentNovels(10)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOrder = MutableStateFlow(NovelSortOrder.RECENT)
    val sortOrder: StateFlow<NovelSortOrder> = _sortOrder.asStateFlow()

    val filteredNovels: StateFlow<List<NovelEntity>> = combine(
        allNovels,
        _searchQuery,
        _sortOrder
    ) { novels, query, sort ->
        val searched = if (query.isBlank()) {
            novels
        } else {
            novels.filter {
                it.title.contains(query, ignoreCase = true) ||
                        (it.author?.contains(query, ignoreCase = true) == true)
            }
        }
        when (sort) {
            NovelSortOrder.RECENT -> searched.sortedByDescending { it.lastOpenedTime }
            NovelSortOrder.TITLE -> searched.sortedBy { it.title.lowercase() }
            NovelSortOrder.PROGRESS -> searched.sortedByDescending { it.readingProgress }
            NovelSortOrder.FAVORITES -> searched.sortedByDescending { it.isFavorite }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _urlImportState = MutableStateFlow(UrlImportUiState())
    val urlImportState: StateFlow<UrlImportUiState> = _urlImportState.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOrder(order: NovelSortOrder) {
        _sortOrder.value = order
    }

    fun toggleFavorite(novelId: Long, isFav: Boolean) {
        viewModelScope.launch {
            novelRepository.toggleFavorite(novelId, isFav)
        }
    }

    fun renameNovel(novelId: Long, newTitle: String) {
        viewModelScope.launch {
            novelRepository.renameNovel(novelId, newTitle.trim())
        }
    }

    fun deleteNovel(novelId: Long) {
        viewModelScope.launch {
            novelRepository.deleteNovel(novelId)
        }
    }

    // URL Import methods
    fun setImportUrl(url: String) {
        _urlImportState.update { it.copy(url = url, errorMessage = null) }
    }

    fun fetchAndExtractFromUrl(customUrl: String? = null) {
        val targetUrl = (customUrl ?: _urlImportState.value.url).trim()
        if (targetUrl.isBlank()) {
            _urlImportState.update { it.copy(errorMessage = "Please enter a valid HTTP/HTTPS novel URL") }
            return
        }

        _urlImportState.update { it.copy(isLoading = true, errorMessage = null, isSavedSuccess = false) }

        viewModelScope.launch {
            val result = parserManager.fetchAndExtract(targetUrl)
            result.onSuccess { extracted ->
                _urlImportState.update {
                    it.copy(
                        isLoading = false,
                        extractedChapter = extracted,
                        editableTitle = extracted.chapterTitle,
                        editableNovelTitle = extracted.novelTitle,
                        editableContent = extracted.content,
                        errorMessage = null
                    )
                }
            }.onFailure { err ->
                _urlImportState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Failed to extract chapter content from webpage"
                    )
                }
            }
        }
    }

    fun updateEditableContent(title: String, novelTitle: String, content: String) {
        _urlImportState.update {
            it.copy(
                editableTitle = title,
                editableNovelTitle = novelTitle,
                editableContent = content
            )
        }
    }

    fun saveImportedChapter(onComplete: (Long) -> Unit = {}) {
        val state = _urlImportState.value
        val extracted = state.extractedChapter ?: return

        val finalExtracted = extracted.copy(
            chapterTitle = state.editableTitle.ifBlank { extracted.chapterTitle },
            novelTitle = state.editableNovelTitle.ifBlank { extracted.novelTitle },
            content = state.editableContent.ifBlank { extracted.content }
        )

        viewModelScope.launch {
            val chapterId = novelRepository.importExtractedChapter(finalExtracted)
            _urlImportState.update { it.copy(isSavedSuccess = true) }
            onComplete(chapterId)
        }
    }

    fun resetImportState() {
        _urlImportState.value = UrlImportUiState()
    }
}
