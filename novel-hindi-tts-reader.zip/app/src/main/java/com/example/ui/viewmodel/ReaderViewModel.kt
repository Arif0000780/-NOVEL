package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.demo.DemoNovelProvider
import com.example.data.local.entity.ChapterEntity
import com.example.data.local.entity.NovelEntity
import com.example.data.local.entity.SettingsEntity
import com.example.data.local.entity.TranslationEntity
import com.example.data.repository.NovelRepository
import com.example.data.repository.SettingsRepository
import com.example.parser.ParserManager
import com.example.translation.CompositeTranslationManager
import com.example.translation.TranslationStyle
import com.example.translation.isPureHindi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ReaderUiState(
    val novel: NovelEntity? = null,
    val chapter: ChapterEntity? = null,
    val allChapters: List<ChapterEntity> = emptyList(),
    val translation: TranslationEntity? = null,
    val showHindi: Boolean = true,
    val isTranslating: Boolean = false,
    val translationError: String? = null,
    val currentParagraphIndex: Int = 0,
    val progressPercent: Float = 0f,
    val isBookmarked: Boolean = false,
    val messageSnackbar: String? = null
)

class ReaderViewModel(
    private val novelRepository: NovelRepository,
    private val settingsRepository: SettingsRepository,
    private val translationManager: CompositeTranslationManager,
    private val parserManager: ParserManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReaderUiState())
    val uiState: StateFlow<ReaderUiState> = _uiState.asStateFlow()

    val settings: StateFlow<SettingsEntity> = settingsRepository.getSettingsFlow()
        .map { it ?: SettingsEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsEntity())

    fun loadChapter(chapterId: Long) {
        viewModelScope.launch {
            val chapter = novelRepository.getChapterById(chapterId) ?: return@launch
            val novel = novelRepository.getNovelById(chapter.novelId)
            val chapters = novelRepository.getChaptersListForNovel(chapter.novelId)
            var translation = novelRepository.getTranslationForChapter(chapterId)

            // If existing translation is not pure Hindi (e.g. outdated mixed text), overwrite with verified demo translation or clear
            if (translation != null && !isPureHindi(translation.translatedContent)) {
                val demoTrans = DemoNovelProvider.getDemoTranslations(chapter.novelId).firstOrNull { it.chapterId == chapter.id }
                if (demoTrans != null) {
                    translation = demoTrans
                    novelRepository.saveTranslation(demoTrans)
                } else {
                    translation = null
                }
            }

            val savedProgress = novelRepository.getReadingProgress(chapterId)

            _uiState.update {
                it.copy(
                    novel = novel,
                    chapter = chapter,
                    allChapters = chapters,
                    translation = translation,
                    showHindi = translation != null && isPureHindi(translation.translatedContent),
                    currentParagraphIndex = savedProgress?.paragraphIndex ?: 0,
                    progressPercent = savedProgress?.progressPercent ?: 0f,
                    translationError = null
                )
            }

            // If auto-translate enabled and no pure Hindi translation yet, trigger translation
            val currentSettings = settingsRepository.getSettings()
            if (currentSettings.autoTranslate && (translation == null || !isPureHindi(translation.translatedContent))) {
                translateChapter(chapter)
            }
        }
    }

    fun translateChapter(
        chapterOverride: ChapterEntity? = null,
        onComplete: ((String) -> Unit)? = null
    ) {
        val targetChapter = chapterOverride ?: _uiState.value.chapter ?: return
        _uiState.update { it.copy(isTranslating = true, translationError = null) }

        viewModelScope.launch {
            // First check if a verified pure Hindi demo translation exists for this chapter
            val demoTrans = DemoNovelProvider.getDemoTranslations(targetChapter.novelId).firstOrNull { it.chapterId == targetChapter.id }
            if (demoTrans != null) {
                novelRepository.saveTranslation(demoTrans)
                _uiState.update {
                    it.copy(
                        translation = demoTrans,
                        showHindi = true,
                        isTranslating = false,
                        translationError = null,
                        messageSnackbar = "हिंदी अनुवाद तैयार है"
                    )
                }
                onComplete?.invoke(demoTrans.translatedContent)
                return@launch
            }

            val currentSettings = settingsRepository.getSettings()
            val style = try {
                TranslationStyle.valueOf(currentSettings.translationStyle)
            } catch (e: Exception) {
                TranslationStyle.NATURAL
            }

            val result = translationManager.translateNovelText(
                text = targetChapter.content,
                style = style,
                providerPreference = currentSettings.translationProvider
            )

            result.onSuccess { translatedText ->
                if (!isPureHindi(translatedText)) {
                    _uiState.update {
                        it.copy(
                            isTranslating = false,
                            translationError = "पूर्ण हिंदी अनुवाद प्राप्त नहीं हुआ। पुनः प्रयास करें।"
                        )
                    }
                    return@onSuccess
                }

                val titleResult = translationManager.translateNovelText(
                    text = targetChapter.title,
                    style = style,
                    providerPreference = currentSettings.translationProvider
                ).getOrDefault(targetChapter.title)

                val translationEntity = TranslationEntity(
                    chapterId = targetChapter.id,
                    sourceLanguage = "auto",
                    targetLanguage = "hi",
                    style = style.name,
                    translatedTitle = titleResult,
                    translatedContent = translatedText
                )
                novelRepository.saveTranslation(translationEntity)

                _uiState.update {
                    it.copy(
                        translation = translationEntity,
                        showHindi = true,
                        isTranslating = false,
                        translationError = null,
                        messageSnackbar = "हिंदी अनुवाद तैयार है"
                    )
                }
                onComplete?.invoke(translatedText)
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isTranslating = false,
                        translationError = error.localizedMessage ?: "अनुवाद विफल हुआ। पुनः प्रयास करें।"
                    )
                }
            }
        }
    }

    fun toggleLanguage() {
        _uiState.update { it.copy(showHindi = !it.showHindi) }
    }

    fun updateReadingPosition(paragraphIndex: Int, percent: Float) {
        _uiState.update {
            it.copy(currentParagraphIndex = paragraphIndex, progressPercent = percent)
        }
        val chapter = _uiState.value.chapter ?: return
        val novel = _uiState.value.novel ?: return
        viewModelScope.launch {
            novelRepository.updateReadingProgress(novel.id, chapter.id, chapter.chapterNumber, percent, paragraphIndex)
        }
    }

    fun bookmarkCurrentParagraph(note: String = "") {
        val chapter = _uiState.value.chapter ?: return
        val novel = _uiState.value.novel ?: return
        val paraIndex = _uiState.value.currentParagraphIndex
        viewModelScope.launch {
            novelRepository.saveBookmark(
                novelId = novel.id,
                chapterId = chapter.id,
                chapterTitle = chapter.title,
                paragraphIndex = paraIndex,
                note = note
            )
            _uiState.update { it.copy(isBookmarked = true, messageSnackbar = "Bookmark saved at paragraph ${paraIndex + 1}") }
        }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(messageSnackbar = null) }
    }

    // Font and theme updates
    fun increaseFontSize() {
        viewModelScope.launch {
            val current = settings.value.fontSize
            settingsRepository.updateFontSize(current + 2)
        }
    }

    fun decreaseFontSize() {
        viewModelScope.launch {
            val current = settings.value.fontSize
            settingsRepository.updateFontSize(current - 2)
        }
    }

    fun setReaderTheme(themeName: String) {
        viewModelScope.launch {
            settingsRepository.updateReaderTheme(themeName)
        }
    }

    fun setLineSpacing(spacing: Float) {
        viewModelScope.launch {
            settingsRepository.updateLineSpacing(spacing)
        }
    }

    fun setParagraphSpacing(spacing: Int) {
        viewModelScope.launch {
            settingsRepository.updateParagraphSpacing(spacing)
        }
    }

    fun navigateToNextChapter(onSuccess: (Long) -> Unit, onNextUrlNeeded: (String?) -> Unit) {
        val currentChapter = _uiState.value.chapter ?: return
        val allChapters = _uiState.value.allChapters

        // Check if next chapter already imported
        val nextInDb = allChapters.firstOrNull { it.chapterNumber == currentChapter.chapterNumber + 1 }
        if (nextInDb != null) {
            loadChapter(nextInDb.id)
            onSuccess(nextInDb.id)
            return
        }

        // If next chapter URL is available, notify caller or load
        if (!currentChapter.nextChapterUrl.isNullOrBlank()) {
            onNextUrlNeeded(currentChapter.nextChapterUrl)
        } else {
            onNextUrlNeeded(null)
        }
    }

    fun navigateToPrevChapter(onSuccess: (Long) -> Unit) {
        val currentChapter = _uiState.value.chapter ?: return
        val allChapters = _uiState.value.allChapters
        val prevInDb = allChapters.firstOrNull { it.chapterNumber == currentChapter.chapterNumber - 1 }
        if (prevInDb != null) {
            loadChapter(prevInDb.id)
            onSuccess(prevInDb.id)
        }
    }

    fun fetchAndImportNextChapterFromUrl(url: String, onSuccess: (Long) -> Unit) {
        _uiState.update { it.copy(isTranslating = true, messageSnackbar = "Fetching next chapter...") }
        viewModelScope.launch {
            val result = parserManager.fetchAndExtract(url)
            result.onSuccess { extracted ->
                val nextChapterId = novelRepository.importExtractedChapter(extracted)
                loadChapter(nextChapterId)
                onSuccess(nextChapterId)
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isTranslating = false,
                        messageSnackbar = "Failed to load next chapter: ${err.message}"
                    )
                }
            }
        }
    }
}
