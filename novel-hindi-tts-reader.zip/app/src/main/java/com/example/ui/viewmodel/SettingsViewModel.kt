package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.SettingsEntity
import com.example.data.repository.NovelRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val novelRepository: NovelRepository
) : ViewModel() {

    val settings: StateFlow<SettingsEntity> = settingsRepository.getSettingsFlow()
        .map { it ?: SettingsEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsEntity())

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun updateFontSize(size: Int) {
        viewModelScope.launch {
            settingsRepository.updateFontSize(size)
        }
    }

    fun updateLineSpacing(spacing: Float) {
        viewModelScope.launch {
            settingsRepository.updateLineSpacing(spacing)
        }
    }

    fun updateParagraphSpacing(spacing: Int) {
        viewModelScope.launch {
            settingsRepository.updateParagraphSpacing(spacing)
        }
    }

    fun updateReaderTheme(theme: String) {
        viewModelScope.launch {
            settingsRepository.updateReaderTheme(theme)
        }
    }

    fun updateTranslationStyle(style: String) {
        viewModelScope.launch {
            settingsRepository.updateTranslationStyle(style)
        }
    }

    fun updateTranslationProvider(provider: String) {
        viewModelScope.launch {
            settingsRepository.updateTranslationProvider(provider)
        }
    }

    fun updateSpeechSpeed(speed: Float) {
        viewModelScope.launch {
            settingsRepository.updateSpeed(speed)
        }
    }

    fun updateSpeechPitch(pitch: Float) {
        viewModelScope.launch {
            settingsRepository.updatePitch(pitch)
        }
    }

    fun toggleAutoTranslate(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value
            settingsRepository.updateSettings(current.copy(autoTranslate = enabled))
        }
    }

    fun toggleAutoPlay(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value
            settingsRepository.updateSettings(current.copy(autoPlay = enabled))
        }
    }

    fun toggleAutoNextParagraph(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value
            settingsRepository.updateSettings(current.copy(autoNextParagraph = enabled))
        }
    }

    fun toggleAutoNextChapter(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value
            settingsRepository.updateSettings(current.copy(autoNextChapter = enabled))
        }
    }

    fun toggleWifiOnly(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value
            settingsRepository.updateSettings(current.copy(wifiOnly = enabled))
        }
    }

    fun toggleRetryFailedRequests(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value
            settingsRepository.updateSettings(current.copy(retryFailedRequests = enabled))
        }
    }

    fun clearTranslationCache() {
        viewModelScope.launch {
            novelRepository.clearTranslationCache()
            _statusMessage.value = "Translation cache cleared successfully"
        }
    }

    fun clearReadingData() {
        viewModelScope.launch {
            novelRepository.clearReadingData()
            _statusMessage.value = "Reading progress & audio history cleared"
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            novelRepository.clearReadingData()
            _statusMessage.value = "History cleared"
        }
    }

    fun dismissStatus() {
        _statusMessage.value = null
    }
}
