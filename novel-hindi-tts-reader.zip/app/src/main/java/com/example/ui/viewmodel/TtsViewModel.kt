package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ChapterEntity
import com.example.data.local.entity.SettingsEntity
import com.example.data.local.entity.TtsProgressEntity
import com.example.data.repository.NovelRepository
import com.example.data.repository.SettingsRepository
import com.example.translation.isPureHindi
import com.example.tts.TtsPlaybackManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TtsViewModel(
    private val ttsPlaybackManager: TtsPlaybackManager,
    private val novelRepository: NovelRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val isPlaying: StateFlow<Boolean> = ttsPlaybackManager.isPlaying
    val isPaused: StateFlow<Boolean> = ttsPlaybackManager.isPaused
    val currentParagraph: StateFlow<Int> = ttsPlaybackManager.currentParagraph
    val totalParagraphs: StateFlow<Int> = ttsPlaybackManager.totalParagraphs
    val statusMessage: StateFlow<String> = ttsPlaybackManager.statusMessage
    val novelTitle: StateFlow<String> = ttsPlaybackManager.novelTitle
    val chapterTitle: StateFlow<String> = ttsPlaybackManager.chapterTitle
    val activeChapterId: StateFlow<Long?> = ttsPlaybackManager.chapterId

    val speed: StateFlow<Float> = ttsPlaybackManager.speed
    val pitch: StateFlow<Float> = ttsPlaybackManager.pitch

    val settings: StateFlow<SettingsEntity> = settingsRepository.getSettingsFlow()
        .map { it ?: SettingsEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsEntity())

    val speedOptions = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f, 3.5f, 4.0f, 4.5f, 5.0f)

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        viewModelScope.launch {
            val savedSettings = settingsRepository.getSettings()
            ttsPlaybackManager.setSpeed(savedSettings.speechSpeed)
            ttsPlaybackManager.setPitch(savedSettings.speechPitch)
            if (savedSettings.ttsVoice != "default") {
                ttsPlaybackManager.setVoice(savedSettings.ttsVoice)
            }
        }
    }

    fun startPlayback(
        novelTitle: String,
        chapter: ChapterEntity,
        hindiText: String,
        startParagraph: Int = 0
    ) {
        startPlayback(
            novelTitle = novelTitle,
            chapterTitle = chapter.title,
            chapterId = chapter.id,
            hindiText = hindiText,
            startParagraph = startParagraph
        )
    }

    fun startPlayback(
        novelTitle: String,
        chapterTitle: String,
        chapterId: Long,
        hindiText: String,
        startParagraph: Int = 0
    ) {
        if (hindiText.isBlank() || !isPureHindi(hindiText)) {
            _userMessage.value = "हिंदी ऑडियो उपलब्ध नहीं है। कृपया पहले पूरा हिंदी अनुवाद करें।"
            return
        }

        ttsPlaybackManager.prepareChapter(
            novelTitle = novelTitle,
            chapterTitle = chapterTitle,
            chapterId = chapterId,
            text = hindiText,
            startParagraph = startParagraph
        )
        ttsPlaybackManager.play()

        viewModelScope.launch {
            novelRepository.saveTtsProgress(
                TtsProgressEntity(
                    chapterId = chapterId,
                    paragraphIndex = startParagraph,
                    speed = speed.value,
                    pitch = pitch.value
                )
            )
        }
    }

    fun play() = ttsPlaybackManager.play()
    fun pause() = ttsPlaybackManager.pause()
    fun resume() = ttsPlaybackManager.resume()
    fun stop() = ttsPlaybackManager.stop()
    fun nextParagraph() = ttsPlaybackManager.nextParagraph()
    fun prevParagraph() = ttsPlaybackManager.prevParagraph()
    fun seekToParagraph(index: Int) = ttsPlaybackManager.seekToParagraph(index)

    fun setSpeed(speedVal: Float) {
        val clamped = speedVal.coerceIn(0.5f, 5.0f)
        ttsPlaybackManager.setSpeed(clamped)
        viewModelScope.launch {
            settingsRepository.updateSpeed(clamped)
        }
    }

    fun setPitch(pitchVal: Float) {
        val clamped = pitchVal.coerceIn(0.5f, 2.0f)
        ttsPlaybackManager.setPitch(clamped)
        viewModelScope.launch {
            settingsRepository.updatePitch(clamped)
        }
    }

    fun selectVoice(voiceName: String) {
        ttsPlaybackManager.setVoice(voiceName)
        viewModelScope.launch {
            settingsRepository.updateVoice(voiceName)
        }
    }

    fun getInstalledHindiVoices() = ttsPlaybackManager.getInstalledVoices()

    fun dismissMessage() {
        _userMessage.value = null
    }
}
