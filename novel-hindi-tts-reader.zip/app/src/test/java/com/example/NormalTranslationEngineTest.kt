package com.example

import com.example.translation.NormalTranslationEngine
import com.example.translation.SupportedLanguages
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NormalTranslationEngineTest {

    @Test
    fun supportedLanguages_containsRequiredLanguages() {
        val sourceCodes = SupportedLanguages.SOURCE_LANGUAGES.map { it.code }
        val targetCodes = SupportedLanguages.TARGET_LANGUAGES.map { it.code }

        // Must include Auto Detect in source
        assertTrue(sourceCodes.contains("auto"))

        // Common languages requested
        val required = listOf("en", "hi", "ur", "ar", "bn", "ta", "te", "mr", "gu", "pa", "fr", "de", "es", "ja", "ko")
        for (lang in required) {
            assertTrue("Source languages should contain $lang", sourceCodes.contains(lang))
            assertTrue("Target languages should contain $lang", targetCodes.contains(lang))
        }

        // Check Chinese
        assertTrue(sourceCodes.any { it.startsWith("zh") })
        assertTrue(targetCodes.any { it.startsWith("zh") })

        val hindi = SupportedLanguages.findLanguage("hi")
        assertEquals("Hindi", hindi.name)
        assertEquals("हिन्दी", hindi.nativeName)
    }

    @Test
    fun sameSourceAndTarget_returnsOriginalText() = runBlocking {
        val original = "This is test text.\n\nPreserving paragraphs perfectly."
        val result = NormalTranslationEngine.translateCompleteText(original, "en", "en")
        assertTrue(result.isSuccess)
        assertEquals(original, result.getOrNull())
    }

    @Test
    fun emptyInput_returnsEmptyResult() = runBlocking {
        val result = NormalTranslationEngine.translateCompleteText("   ", "auto", "hi")
        assertTrue(result.isSuccess)
        assertEquals("", result.getOrNull())
    }

    @Test
    fun translation_preservesParagraphStructure() = runBlocking {
        val multiParagraph = "Hello world.\n\nGood morning.\n\nHave a nice day."
        val result = NormalTranslationEngine.translateCompleteText(multiParagraph, "en", "hi")
        if (result.isSuccess) {
            val output = result.getOrNull()
            assertNotNull(output)
            val paras = output!!.split("\n\n")
            assertEquals("Should preserve 3 paragraphs", 3, paras.size)
        }
    }
}
