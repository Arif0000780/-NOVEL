package com.example

import com.example.data.demo.DemoNovelProvider
import com.example.translation.isPureHindi
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NovelReaderTranslationTest {

    @Test
    fun isPureHindi_correctlyIdentifiesPureHindiAndMixedText() {
        val pureHindi = "हिमालय की नुकीली बर्फीली चोटियों पर भोर की पहली किरण फूटी।"
        assertTrue("Devanagari text should be pure Hindi", isPureHindi(pureHindi))

        val mixedText = "Vikram ने अपना leather bag tight किया और mountain air में breath ली।"
        assertFalse("Mixed Hinglish text should NOT be identified as pure Hindi", isPureHindi(mixedText))

        val pureEnglish = "The dawn broke over the jagged snowy peaks of the Himalayas."
        assertFalse("Pure English text should NOT be pure Hindi", isPureHindi(pureEnglish))

        assertFalse("Empty text should return false", isPureHindi(""))
        assertFalse("Whitespace text should return false", isPureHindi("   "))
    }

    @Test
    fun demoTranslations_areAllPureHindiWithoutMixedText() {
        val demoTranslations = DemoNovelProvider.getDemoTranslations(1)
        assertTrue("Demo translations should not be empty", demoTranslations.isNotEmpty())

        for (translation in demoTranslations) {
            assertTrue(
                "Title '${translation.translatedTitle}' should be pure Hindi",
                isPureHindi(translation.translatedTitle)
            )
            assertTrue(
                "Content of Chapter ${translation.chapterId} should be pure Hindi without mixed English",
                isPureHindi(translation.translatedContent)
            )

            val paragraphs = translation.translatedContent.split("\n\n")
                .map { it.trim() }
                .filter { it.isNotBlank() }

            for ((pIdx, paragraph) in paragraphs.withIndex()) {
                assertTrue(
                    "Chapter ${translation.chapterId} paragraph $pIdx must be pure Hindi without English sentences",
                    isPureHindi(paragraph)
                )
            }
        }
    }
}
