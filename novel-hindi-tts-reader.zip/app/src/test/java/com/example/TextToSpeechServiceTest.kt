package com.example

import com.example.tts.TextToSpeechService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TextToSpeechServiceTest {

    @Test
    fun speechRate_isWithinSupportedRange() {
        assertEquals(0.5f, TextToSpeechService.MIN_SPEECH_RATE)
        assertEquals(5.0f, TextToSpeechService.MAX_SPEECH_RATE)

        // Verify clamping logic boundaries
        val belowMin = 0.2f.coerceIn(TextToSpeechService.MIN_SPEECH_RATE, TextToSpeechService.MAX_SPEECH_RATE)
        val normal = 1.0f.coerceIn(TextToSpeechService.MIN_SPEECH_RATE, TextToSpeechService.MAX_SPEECH_RATE)
        val fast = 3.5f.coerceIn(TextToSpeechService.MIN_SPEECH_RATE, TextToSpeechService.MAX_SPEECH_RATE)
        val aboveMax = 6.5f.coerceIn(TextToSpeechService.MIN_SPEECH_RATE, TextToSpeechService.MAX_SPEECH_RATE)

        assertEquals(0.5f, belowMin)
        assertEquals(1.0f, normal)
        assertEquals(3.5f, fast)
        assertEquals(5.0f, aboveMax)
    }

    @Test
    fun playbackStates_containsRequiredControls() {
        val states = TextToSpeechService.PlaybackState.values().map { it.name }
        assertTrue(states.contains("IDLE"))
        assertTrue(states.contains("INITIALIZING"))
        assertTrue(states.contains("PLAYING"))
        assertTrue(states.contains("PAUSED"))
        assertTrue(states.contains("STOPPED"))
        assertTrue(states.contains("ERROR"))
    }

    @Test
    fun intentActions_areProperlyDefined() {
        assertEquals("com.example.tts.action.PLAY", TextToSpeechService.ACTION_PLAY)
        assertEquals("com.example.tts.action.PAUSE", TextToSpeechService.ACTION_PAUSE)
        assertEquals("com.example.tts.action.RESUME", TextToSpeechService.ACTION_RESUME)
        assertEquals("com.example.tts.action.STOP", TextToSpeechService.ACTION_STOP)
        assertEquals("com.example.tts.action.SET_RATE", TextToSpeechService.ACTION_SET_RATE)
    }
}
